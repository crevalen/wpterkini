<?php postViews(get_the_ID()); ?>
<?php get_template_part("header"); ?>
<?php get_template_part("template-parts/header/index"); ?>
<?php get_template_part("template-parts/single/index"); ?>
<?php get_template_part("footer"); ?>