<?php 
/* 
Template Name: Template Indeks
*/
get_template_part("header"); ?>
<?php get_template_part("template-parts/header/index"); ?>
<?php get_template_part("template-parts/indeks/index"); ?>
<?php get_template_part("footer"); ?>