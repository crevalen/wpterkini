<?php 
function addcss() { 
    $versi = '1.0.0';
    wp_enqueue_style( 'menu-image', get_template_directory_uri() . '/assets/css/menu-image.css', '', $versi );
    wp_enqueue_style( 'normalize', get_template_directory_uri() . '/assets/css/normalize.css', '', $versi );
    wp_enqueue_style( 'font', get_template_directory_uri() . '/assets/css/font.css', '', $versi );
    wp_enqueue_style( 'slick', get_template_directory_uri() . '/assets/css/slick.css', $versi );
    if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
      wp_enqueue_style( 'amp', get_template_directory_uri() . '/assets/css/amp.css', '', $versi );
  	}elseif(wp_is_mobile()) {
        if(is_page_template('indeks.php')) :
          wp_enqueue_style( 'daterange', get_template_directory_uri() . '/assets/css/pikaday.css', '', $versi );
        endif;
      wp_enqueue_style( 'mobile', get_template_directory_uri() . '/assets/css/mobile.css', '', $versi );
    }else {
        if(is_page_template('indeks.php')) :
          wp_enqueue_style( 'daterange', get_template_directory_uri() . '/assets/css/pikaday.css', '', $versi );
        endif;
      wp_enqueue_style( 'desktop', get_template_directory_uri() . '/assets/css/desktop.css', '', $versi );
    }
}
add_action( 'wp_enqueue_scripts', 'addcss' );

function addattrcss( $html, $handle ) {
    if ('menu-image' === $handle 
        || 'normalize' === $handle 
        || 'dashicons' === $handle 
        || 'icon' === $handle 
        || 'admin-bar' === $handle 
        || 'wp-block-library' === $handle 
        || 'menu-image' === $handle 
        || 'font' === $handle 
        || 'slick' === $handle 
        || 'darkmode' === $handle 
        || 'amp' === $handle 
        || 'mobile' === $handle 
        || 'desktop' === $handle 
    ) :
        return str_replace( "media='all'", "media='all' async='async'", $html );
    endif;
    return $html;
}
add_filter( 'style_loader_tag', 'addattrcss', 10, 2 );

add_action( 'admin_enqueue_scripts', 'load_admin_styles' );
function load_admin_styles() {
    $versi = '1.0.0';
    wp_enqueue_style( 'admin_css_foo', get_template_directory_uri() . '/assets/css/admin.css', false, $versi );
}
function customcss()
{
?>
<style type="text/css" id="custom-theme-css">
:root {
<?php if(!empty(get_theme_mod( 'color1' ))):?>
  --color2: <?php echo get_theme_mod( 'color1' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'color2' ))):?>
  --color3: <?php echo get_theme_mod( 'color2' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'color3' ))):?>
  --color4: <?php echo get_theme_mod( 'color3' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'textparallax' ))):?>
  --textparallax: '<?php echo get_theme_mod( 'textparallax' ); ?>';
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'widthparallaxmobile' ))):?>
  --widthparallaxmobile: <?php echo get_theme_mod( 'widthparallaxmobile' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'heightparallaxmobile' ))):?>
  --heightparallaxmobile: <?php echo get_theme_mod( 'heightparallaxmobile' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'widthparallaxdesktop' ))):?>
  --widthparallaxdesktop: <?php echo get_theme_mod( 'widthparallaxdesktop' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'heightparallaxdesktop' ))):?>
  --heightparallaxdesktop: <?php echo get_theme_mod( 'heightparallaxdesktop' ); ?>;
<?php endif; ?>

}
</style>
<?php
}
add_action( 'wp_head', 'customcss');