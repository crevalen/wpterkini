<?php 
add_shortcode( 'pospopuler', 'pospopuler_shortcode' );
function pospopuler_shortcode( $atts ) {
	global $post;
	$rentang = $atts["rentang"];
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	$args = array(
		'post_type' => 'post',
		'post_status' => 'publish',
		'paged' => $paged,
		'meta_key' => 'post_views_count',
		'orderby'   => 'meta_value_num',
		'posts_per_page'=> $jml,
		'order' => 'DESC',
		'date_query' => array(
			array(
				'after' => $rentang,
			),
		)
	);

	$konten = "";
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ):
		$konten .= '<div class="widget-content">';
			while ($my_query->have_posts()) {
				$my_query->the_post();
   					$counter = get_post_meta( get_the_ID(), 'counter', true );
				if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
						$konten .= '<div class="indeks-item media">
								<div class="indeks-image media-image">';
			                         if($counter["video"] != ""):
			                              $konten .= '<div class="video-time"></div>';
			                         endif;
			                         if($counter["foto"] != ""):
			                              $konten .= '<div class="foto-counter"></div>';
			                         endif;
									$konten .= customthumbnail(get_the_ID(), 'thumbnail'). '
								</div>
									<div class="indeks-text">';
										$konten .= '<h2>
											<a href="' . get_permalink() . '" class="media-title">' . get_the_title() . '</a>
										</h2><div class="indeks-meta">';
										if(!empty(labelcategory())):
											$konten .= '<div class="indeks-category">' . labelcategory() . '</div>';
										endif;
									$konten .= '<div class="indeks-date">' . get_the_date( get_option('date_format') ) . ', ' . get_the_time( get_option('time_format') ) . '</div></div>
									</div>
							</div>';
				}elseif (wp_is_mobile()) {
						$konten .= '<div class="indeks-item media">
								<div class="indeks-image media-image">';
			                         if($counter["video"] != ""):
			                              $konten .= '<div class="video-time"></div>';
			                         endif;
			                         if($counter["foto"] != ""):
			                              $konten .= '<div class="foto-counter"></div>';
			                         endif;
									$konten .= customthumbnail(get_the_ID(), 'thumbnail'). '
								</div>
									<div class="indeks-text">';
										$konten .= '<h2>
											<a href="' . get_permalink() . '" class="media-title">' . get_the_title() . '</a>
										</h2><div class="indeks-meta">';
										if(!empty(labelcategory())):
											$konten .= '<div class="indeks-category">' . labelcategory() . '</div>';
										endif;
									$konten .= '<div class="indeks-date">' . get_the_date( get_option('date_format') ) . ', ' . get_the_time( get_option('time_format') ) . '</div></div>
									</div>
							</div>';
				}else{
					$konten .= '<div class="indeks-item media">
							<div class="indeks-image media-image">';
	                         if($counter["video"] != ""):
	                              $konten .=  '<div class="video-time">' . $counter["video"]. '</div>';
	                         endif;

	                         if($counter["foto"] != ""):
	                              $konten .=  '<div class="foto-counter">' . $counter["foto"]. ' Foto</div>';
	                         endif;
							$konten .= customthumbnail(get_the_ID(), 'image_198_114'). '
							</div>
							<div class="indeks-text">';
								if(!empty(labelcategory())):
									$konten .= '<div class="indeks-category">' . labelcategory() . '</div>';
								endif;
								$konten .= '<h2>
									<a href="' . get_permalink() . '" class="media-title">' . get_the_title() . '</a>
								</h2>
										<div class="indeks-date">' . get_the_date( get_option('date_format') ) . ', ' . get_the_time( get_option('time_format') ) . '</div>
							</div>
						</div>';
				}
			}
		wp_reset_postdata();
		$konten .= '</div><div class="widget-pagination">';
		$konten .= '<div class="widget-pagination">
				<div class="status">
					<div class="pagination-index">
						<a href="javascript:void(0)" class="trigger">Lihat lainnya</a>
					</div>
					<div class="loading">
						<svg class="td-loader__circle" viewBox="25 25 50 50">
							<circle class="td-loader__path" cx="50" cy="50" r="20" fill="none" stroke-width="4" stroke-miterlimit="10"></circle>
						</svg>
					</div>
					<div class="no-more">Artikel sudah termuat semua...</div>
				</div>
				<div class="pagination-index loadmore">';
					$konten .= get_next_posts_link("Lihat lainnya", $my_query->max_num_pages );
				$konten .= '</div>
			</div>';
		$konten .= '</div>';
	endif;
	return $konten;
}
?>