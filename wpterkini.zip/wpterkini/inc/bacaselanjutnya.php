<?php 
add_shortcode( 'bacaselanjutnya', 'bacaselanjutnya_shortcode' );
function bacaselanjutnya_shortcode( $atts ) {
	global $post;
	$prev_post = get_previous_post();
	$prev_post_id = $prev_post->ID;
	$title = $atts["judul"];

	$args = array(
	   'p' => $prev_post_id,
	   'post_type' => 'post',
	   'post_status' => 'publish',
	   'posts_per_page'=> 1
	);

	$konten = "";
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ):
			while ($my_query->have_posts()) {
               	$my_query->the_post(); 
               	$counter = get_post_meta( get_the_ID(), 'counter', true );
				$konten .= '<div class="next-article">
               <div class="next-box">
                    <div class="next-image media-image">';
						if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
							 if($counter["video"] != ""):
	                              $konten .= '<div class="video-time"></div>';
	                        endif;
							if($counter["foto"] != ""):
							  $konten .= '<div class="foto-counter"></div>';
							endif;
                        	$konten .= customthumbnail(get_the_ID(), 'thumbnail');
						}elseif (wp_is_mobile()) {
							 if($counter["video"] != ""):
	                              $konten .= '<div class="video-time"></div>';
	                        endif;
							if($counter["foto"] != ""):
							  $konten .= '<div class="foto-counter"></div>';
							endif;
                        	$konten .= customthumbnail(get_the_ID(), 'thumbnail');
						}else{
	                        if($counter["video"] != ""):
	                              $konten .= '<div class="video-time">' . $counter["video"] . '</div>';
	                        endif;
							if($counter["foto"] != ""):
							  $konten .= '<div class="foto-counter">' . $counter["foto"]. ' Foto</div>';
							endif;
                        	$konten .= customthumbnail(get_the_ID(), 'image_198_114');
						}
                    $konten .= '</div>
	                    <div class="next-text">
	                         <div class="next-label">' . $title . '</div>
	                         <div class="next-title">
	                              <a class="media-title" href="'. get_the_permalink() .'">' . get_the_title() . '</a>
	                         </div>
	                    </div>
	               </div>
	          </div>';
			}
	wp_reset_postdata();
	endif;
	return $konten;
}
?>