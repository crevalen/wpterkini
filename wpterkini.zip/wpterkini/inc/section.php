<?php 
function sidebar_menu() {
global $app;
$args = array(
  'name'          => $app["section"]["sidebar_menu"]["name"], 
  'id'            => 'sidebar_menu',
  'description'   => $app["section"]["sidebar_menu"]["description"],
  'before_widget' => '<div class="widget">',
  'after_widget'  => '</div>',
  'before_title'  => '<div class="sidebar-header"><h2 class="sidebar-title">',
  'after_title'   => '</h2></div>',
);
register_sidebar( $args );
}
add_action( 'widgets_init', 'sidebar_menu' );


function parallax_mobile() {
global $app;
    $args = array(
      'name'          => $app["section"]["parallax_mobile"]["name"], 
      'id'            => 'parallax_mobile',
      'description'   => $app["section"]["parallax_mobile"]["description"],
      'before_widget' => '<div class="widget"><div class="widget-parallax">',
      'after_widget'  => '</div></div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'parallax_mobile' );

function parallax_desktop() {
global $app;
    $args = array(
      'name'          => $app["section"]["parallax_desktop"]["name"], 
      'id'            => 'parallax_desktop',
      'description'   => $app["section"]["parallax_desktop"]["description"],
      'before_widget' => '<div class="widget"><div class="widget-parallax">',
      'after_widget'  => '</div></div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'parallax_desktop' );

function billboard_area() {
global $app;
    $args = array(
      'name'          => $app["section"]["billboard_area"]["name"], 
      'id'            => 'billboard_area',
      'description'   => $app["section"]["billboard_area"]["description"],
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'billboard_area' );

function homepage_area() {
global $app;
    $args = array(
      'name'          => $app["section"]["homepage_area"]["name"], 
      'id'            => 'homepage_area',
      'description'   => $app["section"]["homepage_area"]["description"],
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'homepage_area' );

function afterpos_area() {
global $app;
    $args = array(
      'name'          => $app["section"]["afterpos_area"]["name"], 
      'id'            => 'afterpos_area',
      'description'   => $app["section"]["afterpos_area"]["description"],
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'afterpos_area' );

function sidebar_area() {
global $app;
    $args = array(
      'name'          => $app["section"]["sidebar_area"]["name"], 
      'id'            => 'sidebar_area',
      'description'   => $app["section"]["sidebar_area"]["description"],
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sidebar_area' );

function sidebarpos_area() {
global $app;
    $args = array(
      'name'          => $app["section"]["sidebarpos_area"]["name"], 
      'id'            => 'sidebarpos_area',
      'description'   => $app["section"]["sidebarpos_area"]["description"],
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sidebarpos_area' );

function sidebararchive_area() {
global $app;
    $args = array(
      'name'          => $app["section"]["sidebararchive_area"]["name"], 
      'id'            => 'sidebararchive_area',
      'description'   => $app["section"]["sidebararchive_area"]["description"],
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sidebararchive_area' );


function footer_top() {
global $app;
    $args = array(
      'name'          => $app["section"]["footer_top"]["name"], 
      'id'            => 'footer_top',
      'description'   => $app["section"]["footer_top"]["description"],
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'footer_top' );

function footer_bottom() {
global $app;
    $args = array(
      'name'          => $app["section"]["footer_bottom"]["name"], 
      'id'            => 'footer_bottom',
      'description'   => $app["section"]["footer_bottom"]["description"],
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'footer_bottom' );

function sticky_ads_post() {
global $app;
    $args = array(
      'name'          => $app["section"]["sticky_ads_post"]["name"], 
      'id'            => 'sticky_ads_post',
      'description'   => $app["section"]["sticky_ads_post"]["description"],
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sticky_ads_post' );

function sticky_ads_left() {
global $app;
    $args = array(
      'name'          => $app["section"]["sticky_ads_left"]["name"], 
      'id'            => 'sticky_ads_left',
      'description'   => $app["section"]["sticky_ads_left"]["description"],
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sticky_ads_left' );

function sticky_ads_right() {
global $app;
    $args = array(
      'name'          => $app["section"]["sticky_ads_right"]["name"], 
      'id'            => 'sticky_ads_right',
      'description'   => $app["section"]["sticky_ads_right"]["description"],
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sticky_ads_right' );

function sticky_ads_bottom() {
global $app;
    $args = array(
      'name'          => $app["section"]["sticky_ads_bottom"]["name"], 
      'id'            => 'sticky_ads_bottom',
      'description'   => $app["section"]["sticky_ads_bottom"]["description"],
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sticky_ads_bottom' );

?>