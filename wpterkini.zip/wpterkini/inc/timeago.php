<?php 
function gettime($format){
	if($format == "timeago"){
		$dateFormat = human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' yang lalu';
		$code = $dateFormat;
	}else{
		$code = get_the_date($format);
	}
	return $code;
}
?>