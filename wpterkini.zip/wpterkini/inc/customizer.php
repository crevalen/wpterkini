<?php 
function addCustomize($wp_customize) {
	global $app;
	$wp_customize->add_panel( 'ThemesappPos', array(
	  'title' => 'Themesapp',
	  'priority' => 162,
	));

		// Warna =========================================================== 
		$wp_customize->add_section( 'color', array(
	    	'title' => $app["customizer"]["color"]["title"],
		  	'description'=> $app["customizer"]["color"]["description"],
			'panel' => 'ThemesappPos',
	    ));
	    $wp_customize->add_setting( 'color1' , array(
	        'default'     => "#ce0a46",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'color1', array(
	        'label'        => $app["customizer"]["color"]["color1"],
	        'section'    => 'color',
	    )));
	    $wp_customize->add_setting( 'color2' , array(
	        'default'     => "#ed3833",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'color2', array(
	        'label'        => $app["customizer"]["color"]["color2"],
	        'section'    => 'color',
	    )));
	    $wp_customize->add_setting( 'color3' , array(
	        'default'     => "#f4a300",
	        'transport'   => 'refresh',
	    ));
	    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'color3', array(
	        'label'        => $app["customizer"]["color"]["color3"],
	        'section'    => 'color',
	    )));

		
		
		/* UNGGULAN */
		$wp_customize->add_section( 'featuredimage' , array(
		  'title'      => $app["customizer"]["featuredimage"]["title"], 
		  'panel' => 'ThemesappPos',
		  'description'=> $app["customizer"]["featuredimage"]["description"],
		));
		$wp_customize->add_setting( 'featuredimageactivepos' , array(
			'default'    => false,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('featuredimageactivepos' , array(
			'section' => 'featuredimage',
			'label' => $app["customizer"]["featuredimage"]["featuredimageactivepos"],
			'type'=>'checkbox',
		));

		$wp_customize->add_setting( 'featuredimageactivepage' , array(
			'default'    => false,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('featuredimageactivepage' , array(
			'section' => 'featuredimage',
			'label' => $app["customizer"]["featuredimage"]["featuredimageactivepage"],
			'type'=>'checkbox',
		));
		$wp_customize->add_setting( 'categoryfeaturedimagea' , array(
			'default'    => '',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('categoryfeaturedimagea' , array(
			'section' => 'featuredimage',
			'label' => $app["customizer"]["featuredimage"]["categoryfeaturedimagea"],
			'type'=>'text',
		));

		/* REDAKSI */
		$wp_customize->add_section( 'timredaksi' , array(
		  'title'      => $app["customizer"]["timredaksi"]["title"],     
		  'panel' => 'ThemesappPos',
		  'description'=> $app["customizer"]["timredaksi"]["description"],
		));

		$wp_customize->add_setting( 'timredaksiactive' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('timredaksiactive' , array(
			'label' => $app["customizer"]["timredaksi"]["timredaksiactive"],
			'section' => 'timredaksi',
			'type'=>'checkbox',
		));
		$wp_customize->add_setting( 'tombolredaksititle' , array(
			'default'    => $app["customizer"]["timredaksi"]["valuetombolredaksititle"],
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolredaksititle' , array(
			'section' => 'timredaksi',
			'label' => $app["customizer"]["timredaksi"]["tombolredaksititle"],
			'type'=>'text',
		));
		$wp_customize->add_setting( 'timredaksipenulis' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('timredaksipenulis' , array(
			'label' => $app["customizer"]["timredaksi"]["timredaksipenulis"],
			'section' => 'timredaksi',
			'type'=>'checkbox',
		));

		$wp_customize->add_setting( 'timredaksieditor' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('timredaksieditor' , array(
			'label' => $app["customizer"]["timredaksi"]["timredaksieditor"],
			'section' => 'timredaksi',
			'type'=>'checkbox',
		));
		$wp_customize->add_setting( 'timredaksireporter' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('timredaksireporter' , array(
			'label' => $app["customizer"]["timredaksi"]["timredaksireporter"],
			'section' => 'timredaksi',
			'type'=>'checkbox',
		));

			
		/* SHARE */
		$wp_customize->add_section( 'tombolbagikan' , array(
		  'title'      => $app["customizer"]["tombolbagikan"]["title"],     
		  'panel' => 'ThemesappPos',
		  'description'=> $app["customizer"]["tombolbagikan"]["description"],
		));
		$wp_customize->add_setting( 'tombolwhatsapp' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolwhatsapp' , array(
			'label' => $app["customizer"]["tombolbagikan"]["tombolwhatsapp"],
			'section' => 'tombolbagikan',
			'type'=>'checkbox',
		));
		$wp_customize->add_setting( 'tombolfacebook' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolfacebook' , array(
			'label' => $app["customizer"]["tombolbagikan"]["tombolfacebook"],
			'section' => 'tombolbagikan',
			'type'=>'checkbox',
		));
		$wp_customize->add_setting( 'tomboltwitter' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tomboltwitter' , array(
			'label' => $app["customizer"]["tombolbagikan"]["tomboltwitter"],
			'section' => 'tombolbagikan',
			'type'=>'checkbox',
		));

		$wp_customize->add_setting( 'tomboltelegram' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tomboltelegram' , array(
			'label' => $app["customizer"]["tombolbagikan"]["tomboltelegram"],
			'section' => 'tombolbagikan',
			'type'=>'checkbox',
		));

		$wp_customize->add_setting( 'tombolcopylink' , array(
			'default'    => true,
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('tombolcopylink' , array(
			'label' => $app["customizer"]["tombolbagikan"]["tombolcopylink"],
			'section' => 'tombolbagikan',
			'type'=>'checkbox',
		));

		/* ads parallax */
		$wp_customize->add_section( 'parallax' , array(
		  'title'      => $app["customizer"]["parallax"]["title"],     
		  'panel' => 'ThemesappPos',
		  'description'=> $app["customizer"]["parallax"]["description"],
		));
		$wp_customize->add_setting( 'widthparallaxmobile' , array(
			'default'    => '300px',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('widthparallaxmobile' , array(
			'section' => 'parallax',
			'label' => $app["customizer"]["parallax"]["widthparallaxmobile"],
			'type'=>'text',
		));
		$wp_customize->add_setting( 'heightparallaxmobile' , array(
			'default'    => '600px',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('heightparallaxmobile' , array(
			'section' => 'parallax',
			'label' => $app["customizer"]["parallax"]["heightparallaxmobile"],
			'type'=>'text',
		));
		$wp_customize->add_setting( 'widthparallaxdesktop' , array(
			'default'    => '100%',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('widthparallaxdesktop' , array(
			'section' => 'parallax',
			'label' => $app["customizer"]["parallax"]["widthparallaxdesktop"],
			'type'=>'text',
		));
		$wp_customize->add_setting( 'heightparallaxdesktop' , array(
			'default'    => '250px',
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('heightparallaxdesktop' , array(
			'section' => 'parallax',
			'label' => $app["customizer"]["parallax"]["heightparallaxdesktop"],
			'type'=>'text',
		));
		$wp_customize->add_setting( 'textparallax' , array(
			'default'    => $app["customizer"]["parallax"]["valuetextparallax"],
			'transport'  =>  'refresh'
		));
		$wp_customize->add_control('textparallax' , array(
			'section' => 'parallax',
			'label' => $app["customizer"]["parallax"]["textparallax"],
			'type'=>'text',
		));
		
		$wp_customize->add_section( 'licPost' , array(
		  'title'      => $app["customizer"]["licPost"]["title"],     
		  'description'=> $app["customizer"]["licPost"]["description"],
		  'panel' => 'ThemesappPos',
		));

		$wp_customize->add_setting( 'lic' , array(
			'default'    => '',
			'transport'  =>  'postMessage'
		));
		$wp_customize->add_control('lic' , array(
			'section' => 'licPost',
			'label' => $app["customizer"]["licPost"]["lic"],
			'type'=>'text'
		));
			

}
add_action( 'customize_register', 'addCustomize' );

?>