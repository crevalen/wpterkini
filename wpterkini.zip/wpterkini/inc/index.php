<?php 
require 'lang.php';
require 'setup.php';
require 'customizer.php';
require 'custom-post.php';
require 'emoji.php';
require 'thumbnail.php';
require 'menu-image/menu-image-id.php';
require 'css.php';
require 'js.php';
require 'add-menu.php';
require 'section.php';
require 'brand.php';
require 'view.php';
require 'timeago.php';
require 'comment-threads.php';
require 'light_box.php';
require 'lic.php';
require 'get-catergory.php';
require 'bacajuga.php';
require 'bacaselanjutnya.php';
require 'pospopuler.php';
require 'tgmpa/wpterkini.php';
?>