 <?php 
function lightbox_image($content) {
    global $post;
    $pattern        = array('{<figure class="wp-block-image(.*?)"><img decoding="async" width="(.*?)" height="(.*?)" src="(.*?)"(.*?) /><figcaption>(.*?)</figcaption>}','{</figure>}');
    $replacement    = array('<figure class="wp-block-image$1"><div class="wp-image-box"><a class="spotlight" data-description="$6" href="$4"><img Dwidth="$2" height="$3" src="$4"$5/></a></div><figcaption>$6</figcaption>','</figure>');
    $content        = preg_replace($pattern,$replacement,$content);
    return $content;
}
add_filter('the_content','lightbox_image');
?>