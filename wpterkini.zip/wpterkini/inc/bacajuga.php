<?php 
add_shortcode( 'bacajuga', 'bacajuga_shortcode' );
function bacajuga_shortcode( $atts ) {
	global $post;
	$berdasarkan = $atts["berdasarkan"];
	$start = $atts["mulaipos"];
	$title = $atts["judul"];
 	$jml = 1;
	if($berdasarkan == "category"){
	    $categories = get_the_category( $post->ID );
	    $categorieIDs = array();
		if ( $categories ) {
			$categoriecount = count( $categories );
	        for ( $i = 0; $i < $categoriecount; $i++ ) {
	            $categorieIDs[$i] = $categories[$i]->term_id;
	        }
	        $args = array(
	            'category__in' => $categorieIDs,
				'post_type' => 'post',
				'post_status' => 'publish',
      			'offset' => $start,
	            'post__not_in' => array( $post->ID ),
	            'posts_per_page'=> $jml
	        );
	    }
	} else if($berdasarkan == "tag"){
	    $tags = wp_get_post_tags( $post->ID );
	    $tagIDs = array();

		if ( $tags ) {
			$tagcount = count( $tags );
	        for ( $i = 0; $i < $tagcount; $i++ ) {
	            $tagIDs[$i] = $tags[$i]->term_id;
	        }
	        $args = array(
	            'tag__in' => $tagIDs,
				'post_type' => 'post',
				'post_status' => 'publish',
      			'offset' => $start,
	            'post__not_in' => array( $post->ID ),
	            'posts_per_page'=> $jml
	        );
	    }
	}else{
	    $args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
      		'offset' => $start,
	        'post__not_in' => array( $post->ID ),
	        'posts_per_page'=> $jml
	    );

	}
	$konten = "";
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ):
			while ($my_query->have_posts()) {
				$my_query->the_post();
				$konten .= '<div class="bacajuga"><strong>' . $title . '</strong><a href="' . get_permalink() . '">' . get_the_title() . '</a>
</div>';
			}
	wp_reset_postdata();
	endif;
	return $konten;
}
?>