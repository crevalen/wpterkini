<?php 
    function lightbox_image($content) {
        if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
        }else{
            global $post;
            $pattern        = array('{<figure class="wp-block-image(.*?)"><img decoding="async" width="(.*?)" height="(.*?)" src="(.*?)"(.*?) /><figcaption>(.*?)</figcaption>}','{</figure>}');
            $replacement    = array('<figure class="wp-block-image$1"><div class="wp-image-box"><a class="spotlight" data-description="$6" href="$4"><img Dwidth="$2" height="$3" src="$4"$5/></a></div><figcaption>$6</figcaption>','</figure>');
            $content        = preg_replace($pattern,$replacement,$content);
        }
        return $content;
    }
    add_filter('the_content','lightbox_image');
    function lightboxgallery($content) {
        if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
        }else{
            global $post;
            $pattern        = array('{<figure class="(.*?)"><a href="(.*?)">(.*?)</a><figcaption class="wp-element-caption">(.*?)</figcaption>}','{</figure>}');
            $replacement    = array('<figure class="blocks-gallery-item"><a class="spotlight" data-description="$4" href="$2">$3</a>','</figure>');
            $content        = preg_replace($pattern,$replacement,$content);
            return $content;
        }
        return $content;
    }
    add_filter('the_content','lightboxgallery');
?>