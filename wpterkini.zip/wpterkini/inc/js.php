<?php 
function addscript() {
        $versi = '1.0.0';
        if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
        wp_deregister_script('jquery');
        }else{
        wp_enqueue_script('js-jquery', get_stylesheet_directory_uri() . '/assets/js/jquery-3.6.0.min.js',  array(), $versi, true );
        wp_enqueue_script('darkmode', get_stylesheet_directory_uri() . '/assets/js/darkmode.js',  array(), $versi, true );
        if (wp_is_mobile()):
            wp_enqueue_script('mobile', get_stylesheet_directory_uri() . '/assets/js/mobile.js',  array(), $versi, true );
        else:
            wp_enqueue_script('desktop', get_stylesheet_directory_uri() . '/assets/js/desktop.js',  array(), $versi, true );
        endif;
        if(is_author()) :
            wp_enqueue_script('infinity', get_stylesheet_directory_uri() . '/assets/js/infinite-ajax-scroll.min.js',  array(), $versi, true );
            wp_enqueue_script('author', get_stylesheet_directory_uri() . '/assets/js/author.js',  array(), $versi, true );
        endif;
        if(is_category()) :
            wp_enqueue_script('infinity', get_stylesheet_directory_uri() . '/assets/js/infinite-ajax-scroll.min.js',  array(), $versi, true );
            wp_enqueue_script('category', get_stylesheet_directory_uri() . '/assets/js/category.js',  array(), $versi, true );
        endif;
        if(is_home()) :
            wp_enqueue_script('home', get_stylesheet_directory_uri() . '/assets/js/home.js',  array(), $versi, true );
        endif;
        if(is_page()) :
            wp_enqueue_script('page', get_stylesheet_directory_uri() . '/assets/js/page.js',  array(), $versi, true );
        endif;
        if(is_page_template('popular.php')) :
            wp_enqueue_script('infinity', get_stylesheet_directory_uri() . '/assets/js/infinite-ajax-scroll.min.js',  array(), $versi, true );
            wp_enqueue_script('popular', get_stylesheet_directory_uri() . '/assets/js/popular.js',  array(), $versi, true );
        endif;
        if(is_page_template('indeks.php')) :
            wp_enqueue_script('infinity', get_stylesheet_directory_uri() . '/assets/js/infinite-ajax-scroll.min.js',  array(), $versi, true );
            wp_enqueue_script('daterangepicker', get_stylesheet_directory_uri() . '/assets/js/moment.min.js',  array(), $versi, true );
            wp_enqueue_script('daterangepicker', get_stylesheet_directory_uri() . '/assets/js/pikaday.min.js',  array(), $versi, true );
            wp_enqueue_script('indeks', get_stylesheet_directory_uri() . '/assets/js/indeks.js',  array(), $versi, true );
        endif;
        if(is_search()) :
            wp_enqueue_script('infinity', get_stylesheet_directory_uri() . '/assets/js/infinite-ajax-scroll.min.js',  array(), $versi, true );
            wp_enqueue_script('search', get_stylesheet_directory_uri() . '/assets/js/search.js',  array(), $versi, true );
        endif;
        if(is_single()) :
            wp_enqueue_script('fslightbox', get_stylesheet_directory_uri() . '/assets/js/fslightbox.js',  array(), $versi, true );
            wp_enqueue_script('single', get_stylesheet_directory_uri() . '/assets/js/single.js',  array(), $versi, true );
        endif;
        if(is_tag()) :
            wp_enqueue_script('infinity', get_stylesheet_directory_uri() . '/assets/js/infinite-ajax-scroll.min.js',  array(), $versi, true );
            wp_enqueue_script('tag', get_stylesheet_directory_uri() . '/assets/js/tag.js',  array(), $versi, true );
        endif;
        if(is_404()) :
            wp_enqueue_script('error', get_stylesheet_directory_uri() . '/assets/js/error.js',  array(), $versi, true );
        endif;
    }
}
add_action( 'wp_enqueue_scripts', 'addscript' );

function addattrscript( $tag, $handle, $src ) {
    if (
    'hoverintent-js' === $handle 
    ||'admin-bar' === $handle 
    ||'wp-embed' === $handle 
    ||'mobile' === $handle 
    ||'desktop' === $handle 
    ||'author' === $handle 
    ||'category' === $handle 
    ||'home' === $handle 
    ||'page' === $handle 
    ||'popular' === $handle 
    ||'error' === $handle 
    ||'indeks' === $handle 
    ||'search' === $handle 
    ||'single' === $handle 
    ||'tag' === $handle 
    ):
    $tag = str_replace( "src=", "async='async' src=", $tag );
    endif;
    return $tag;
}
add_filter( 'script_loader_tag', 'addattrscript', 10, 3 );
function comments_reply() {
    if( is_singular() && comments_open() && ( get_option( 'thread_comments' ) == 1) ) {
        wp_enqueue_script( 'comment-reply', '/wp-includes/js/comment-reply.min.js', array(), false, true );
    }
}
add_action(  'wp_enqueue_scripts', 'comments_reply' );
?>