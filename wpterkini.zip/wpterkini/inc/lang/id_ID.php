<?php 
$app = [
    'customizer' => [
        'color' => [
            'title'         => 'Warna Situs',
            'description'   => 'Berikut ini adalah pengaturan warna pada situs.',
            'color1'        => 'Warna 1',
            'color2'        => 'Warna 2',
            'color3'        => 'Warna 3',
        ],
        'featuredimage' => [
            'title'                     => 'Gambar Unggulan',
            'description'               => 'Berikut ini adalah pengaturan pada gambar unggulan',
            'featuredimageactivepos'    => 'Tampilkan gambar unggulan dihalaman pos',
            'featuredimageactivepage'    => 'Tampilkan gambar unggulan dihalaman laman',
            'categoryfeaturedimagea'    => 'Daftar kategori tanpa gambar unggulan (pisahkan dengan tanda koma)',
        ],
        'timredaksi' => [
            'title'                     => 'Tim Redaksi',
            'description'               => 'Berikut ini adalah pengaturan tampilan untuk tim redaksi.',
            'timredaksiactive'          => 'Tampilkan tim redaksi',
            'tombolredaksititle'        => 'Judul tim redaksi',
            'valuetombolredaksititle'   => 'Tim Redaksi',
            'timredaksipenulis'         => 'Tampilkan penulis',
            'timredaksieditor'          => 'Tampilkan editor',
            'timredaksireporter'        => 'Tampilkan reporter',
        ],
        'tombolbagikan' => [
            'title'             => 'Tombol Bagikan',
            'description'       => 'Berikut ini adalah pengaturan tampilan tombol share.',
            'tombolwhatsapp'    => 'WhatsApp',
            'tombolfacebook'    => 'Facebook',
            'tomboltwitter'     => 'Twitter',
            'tomboltelegram'    => 'Telegram',
            'tombolcopylink'    => 'Copylink',
        ],
        'parallax' => [
            'title'                 => 'Iklan Parallax',
            'description'           => 'Berikut ini adalah pengaturan tampilan untuk iklan parallax',
            'widthparallaxmobile'   => 'Lebar Iklan Versi Mobile',
            'heightparallaxmobile'  => 'Tinggi Iklan Versi Mobile',
            'widthparallaxdesktop'  => 'Lebar Iklan Versi Desktop',
            'heightparallaxdesktop' => 'Tinggi Iklan Versi Desktop',
            'textparallax'          => 'Keterangan scroll versi mobile',
            'valuetextparallax'     => 'Scroll untuk lanjut membaca',
        ],
        'licPost' => [
            'title'         => 'Lisensi',
            'description'   => 'Berikut ini adalah pengaturan aktivasi lisensi',
            'lic'           => 'Kode lisensi',
        ],

    ],
    'section' => [
        'sidebar_menu' => [
            'name'          => 'Sidebar Menu (Mobile)',
            'description'   => 'Menampilkan widget di sidebar menu versi mobile',
        ],
        'parallax_mobile' => [
            'name'          => 'Iklan Parallax Mobile',
            'description'   => 'Menampilkan iklan parallax (ukuran 300x600 px atau iklan responsif)',
        ],
        'parallax_desktop' => [
            'name'          => 'Iklan Parallax Desktop',
            'description'   => 'Menampilkan iklan parallax (ukuran 970x250 px iklan responsif)',
        ],
        'billboard_area' => [
            'name'          => 'Iklan Billboard',
            'description'   => 'Menampilkan iklan billboard (ukuran 970x250px atau iklan responsif)',
        ],
        'homepage_area' => [
            'name'          => 'Beranda',
            'description'   => 'Menampilkan widget dihalaman beranda.',
        ],
        'afterpos_area' => [
            'name'          => 'Setelah Pos',
            'description'   => 'Menampilkan widget dibagian bawah setelah artikel',
        ],
        'sidebar_area' => [
            'name'          => 'Sidebar Beranda',
            'description'   => 'Menampilkan widget dibagian sidebar dan hanya ditampilkan di halaman beranda.',
        ],
        'sidebarpos_area' => [
            'name'          => 'Sidebar Pos',
            'description'   => 'Menampilkan widget dibagian sidebar dan hanya ditampilkan di halaman pos.',
        ],
        'sidebararchive_area' => [
            'name'          => 'Sidebar Arsip',
            'description'   => 'Menampilkan widget dibagian sidebar dan hanya ditampilkan di halaman arsip seperti kategori, tag, page, dan pencarian.',
        ],
        'footer_top' => [
            'name'          => 'Footer Atas',
            'description'   => 'Menampilkan widget di footer bagian atas',
        ],
        'footer_bottom' => [
            'name'          => 'Footer Bawah',
            'description'   => 'Menampilkan widget di footer bagian bawah',
        ],
        'sticky_ads_post' => [
            'name'          => 'Iklan Melayang Dalam Pos',
            'description'   => 'Menampilkan widget iklan melayang dalam pos (ukuran 160x600 px)',
        ],
        'sticky_ads_left' => [
            'name'          => 'Iklan Melayang Kiri',
            'description'   => 'Menampilkan widget iklan melayang dibagian kiri (ukuran 160x600 px)',
        ],
        'sticky_ads_right' => [
            'name'          => 'Iklan Melayang Kanan',
            'description'   => 'Menampilkan widget iklan melayang dibagian kanan (ukuran 160x600 px)',
        ],
        'sticky_ads_bottom' => [
            'name'          => 'Iklan Melayang Bawah',
            'description'   => 'Menampilkan widget iklan melayang dibagian bawah.',
        ]

    ],
    'menu' => [
        'primary_menu'  => 'Menu Utama (Desktop)',
        'sub_menu'  => 'Sub Menu (Desktop)',
        'mobile_menu'  => 'Menu Utama (Mobile)',
        'network_menu'  => 'Menu Network',
        'social_menu'  => 'Media Sosial',

    ],
    'custompost' => [
        'counter_metabox_id'  => 'Tampilan Counter',
        'foto'  => 'Foto',
        'video'  => 'Video',
        'tim_metabox_id'  => 'Tampilan Tim Redaksi',
        'editor'  => 'Editor',
        'editor_select'  => 'Pilih Editor',
        'reporter'  => 'Reporter',
        'reporter_select'  => 'Pilih Reporter',

    ],
    'widget' => [
        'grid' => [
            'name'          => '✅ Grid',
            'description'   => 'Menampilkan widget yang ditampilkan secara berbaris',
            'label' => [
                'title'         => 'Judul',
                'category'      => 'Kategori',
                'amountdesktop' => 'Jumlah pos di desktop',
                'amountmobile'  => 'Jumlah pos di mobile',
                'desktop'       => 'Tampilkan di versi desktop',
                'mobile'        => 'Tampilkan di versi mobile',
            ],
        ],
        'headline' => [
            'name'          => '✅ Headline',
            'description'   => 'Menampilkan widget khusus headline',
            'label' => [
                'title'         => 'Judul',
                'category'      => 'Kategori',
                'amountdesktop' => 'Jumlah pos di desktop',
                'amountmobile'  => 'Jumlah pos di mobile',
                'desktop'       => 'Tampilkan di versi desktop',
                'mobile'        => 'Tampilkan di versi mobile',
            ],
        ],
        'video' => [
            'name'          => '✅ Video',
            'description'   => 'Menampilkan widget video atau pos lainnya',
            'label' => [
                'title'         => 'Judul',
                'category'      => 'Kategori',
                'amountdesktop' => 'Jumlah pos di desktop',
                'amountmobile'  => 'Jumlah pos di mobile',
                'desktop'       => 'Tampilkan di versi desktop',
                'mobile'        => 'Tampilkan di versi mobile',
            ],
        ],
        'list' => [
            'name'          => '✅ List',
            'description'   => 'Menampilkan widget yang ditampilkan secara berurutan kebawah',
            'label' => [
                'title'         => 'Judul',
                'category'      => 'Kategori',
                'time'          => 'Format tanggal',
                'desctime'      => '<p class="date-time-doc"><a href="https://wordpress.org/support/article/formatting-date-and-time/">Dokumentasi tentang format tanggal dan waktu</a>.</p>',
                'amountdesktop' => 'Jumlah pos di desktop',
                'amountmobile'  => 'Jumlah pos di mobile',
                'desktop'       => 'Tampilkan di versi desktop',
                'mobile'        => 'Tampilkan di versi mobile',
            ],
        ],
        'kolom' => [
            'name'          => '✅ Kolom',
            'description'   => 'Menampilkan widget khusus redaksi dengan thumbnail avatar penulis',
            'label' => [
                'title'         => 'Judul',
                'category'      => 'Kategori',
                'amountdesktop' => 'Jumlah pos di desktop',
                'amountmobile'  => 'Jumlah pos di mobile',
                'desktop'       => 'Tampilkan di versi desktop',
                'mobile'        => 'Tampilkan di versi mobile',
            ],
        ],
        'populartag' => [
            'name'          => '✅ Tag Terpopuler',
            'description'   => 'Menampilkan tag terpopuler dalam rentang waktu tertentu',
            'label' => [
                'title'         => 'Judul',
                'rentang'      => 'Rentang',
                'rentang_select'    => '-- Pilih --',
                'rentang_1day'      => '1 hari',
                'rentang_7day'      => '7 hari',
                'rentang_1month'    => '1 bulan',
                'rentang_1year'     => '1 tahun',
                'amountdesktop' => 'Jumlah pos di desktop',
                'amountmobile'  => 'Jumlah pos di mobile',
                'desktop'       => 'Tampilkan di versi desktop',
                'mobile'        => 'Tampilkan di versi mobile',
            ],
        ],
        'popular' => [
            'name'          => '✅ Pos Terpopuler',
            'description'   => 'Menampilan daftar pos terpopuler berdasarkan rentang tertentu',
            'label' => [
                'title'         => 'Judul',
                'category'      => 'Kategori',
                'rentang'      => 'Rentang',
                'rentang_select'    => '-- Pilih --',
                'rentang_1day'      => '1 hari',
                'rentang_7day'      => '7 hari',
                'rentang_1month'    => '1 bulan',
                'rentang_1year'     => '1 tahun',
                'amountdesktop' => 'Jumlah pos di desktop',
                'amountmobile'  => 'Jumlah pos di mobile',
                'desktop'       => 'Tampilkan di versi desktop',
                'mobile'        => 'Tampilkan di versi mobile',
            ],
        ],
        'related' => [
            'name'          => '✅ Terkait',
            'description'   => 'Menampilkan widget terkait pos berdasarkan kategori atau tag',
            'label' => [
                'title'         => 'Judul',
                'berdasarkan'      => 'Terkait berdasarkan',
                'berdasarkan_select'    => '-- Pilih --',
                'berdasarkan_category'      => 'Kategori',
                'berdasarkan_tag'      => 'Tag',
                'amountdesktop' => 'Jumlah pos di desktop',
                'amountmobile'  => 'Jumlah pos di mobile',
                'desktop'       => 'Tampilkan di versi desktop',
                'mobile'        => 'Tampilkan di versi mobile',
            ],
        ],
        'indeks' => [
            'name'          => '✅ Indeks',
            'description'   => 'Menampilkan widget indeks atau artikel terbaru',
            'label' => [
                'title'         => 'Judul',
                'after'      => 'Mulai pos ke-',
                'time'          => 'Format tanggal',
                'desctime'      => '<p class="date-time-doc"><a href="https://wordpress.org/support/article/formatting-date-and-time/">Dokumentasi tentang format tanggal dan waktu</a>.</p>',
                'amountdesktop' => 'Jumlah pos di desktop',
                'amountmobile'  => 'Jumlah pos di mobile',
                'indeks'      => 'URL tombol index',
                'txtindeks'      => 'Teks tombol index',
                'desktop'       => 'Tampilkan di versi desktop',
                'mobile'        => 'Tampilkan di versi mobile',
            ],
        ],

    ],
];
?>