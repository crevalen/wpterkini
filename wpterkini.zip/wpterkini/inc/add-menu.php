<?php 
global $app;
function primary_menu(){
  $args = array(
    'theme_location'  => 'primary_menu',
    'menu'            => '',
    'container'       => 'nav',
    'container_class' => '',
    'container_id'    => '',
    'menu_class'      => 'widget LinkList',
    'menu_id'         => '',
    'echo'            => true,
    'fallback_cb'     => 'wp_page_menu',
    'before'          => '',
    'after'           => '',
    'link_before'     => '',
    'link_after'      => '',
    'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
    'depth'           => 0,
    'walker'          => '',
  );
  wp_nav_menu($args);
}
function sub_menu(){
  $args = array(
    'theme_location'  => 'sub_menu',
    'menu'            => '',
    'container'       => 'nav',
    'container_class' => '',
    'container_id'    => '',
    'menu_class'      => 'widget LinkList',
    'menu_id'         => '',
    'echo'            => true,
    'fallback_cb'     => 'wp_page_menu',
    'before'          => '',
    'after'           => '',
    'link_before'     => '',
    'link_after'      => '',
    'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
    'depth'           => 0,
    'walker'          => '',
  );
  wp_nav_menu($args);
}

function mobile_menu(){
  $args = array(
    'theme_location'  => 'mobile_menu',
    'menu'            => '',
    'container'       => 'nav',
    'container_class' => '',
    'container_id'    => '',
    'menu_class'      => 'widget LinkList',
    'menu_id'         => '',
    'echo'            => true,
    'fallback_cb'     => 'wp_page_menu',
    'before'          => '',
    'after'           => '',
    'link_before'     => '',
    'link_after'      => '',
    'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
    'depth'           => 0,
    'walker'          => '',
  );
  wp_nav_menu($args);
}
function network_menu(){
  $args = array(
    'theme_location'  => 'network_menu',
    'menu'            => '',
    'container'       => 'nav',
    'container_class' => '',
    'container_id'    => '',
    'menu_class'      => 'widget LinkList',
    'menu_id'         => '',
    'echo'            => true,
    'fallback_cb'     => 'wp_page_menu',
    'before'          => '',
    'after'           => '',
    'link_before'     => '',
    'link_after'      => '',
    'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
    'depth'           => 0,
    'walker'          => '',
  );
  wp_nav_menu($args);
}
function social_menu(){
  $args = array(
    'theme_location'  => 'social_menu',
    'menu'            => '',
    'container'       => 'nav',
    'container_class' => '',
    'container_id'    => '',
    'menu_class'      => 'widget LinkList',
    'menu_id'         => '',
    'echo'            => true,
    'fallback_cb'     => 'wp_page_menu',
    'before'          => '',
    'after'           => '',
    'link_before'     => '',
    'link_after'      => '',
    'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
    'depth'           => 0,
    'walker'          => '',
  );
  wp_nav_menu($args);
}

$register_menu = array(
    'primary_menu' => $app["menu"]["primary_menu"],
    'sub_menu' => $app["menu"]["sub_menu"],
    'mobile_menu' => $app["menu"]["mobile_menu"],
    'network_menu' => $app["menu"]["network_menu"],
    'social_menu' => $app["menu"]["social_menu"],
);
register_nav_menus($register_menu);

?>