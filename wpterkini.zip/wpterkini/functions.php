<?php
require 'inc/index.php';
require 'widget/index.php';
?>