<?php if (is_active_sidebar('billboard_area')) : ?>
	<div class="billboard">
		<div class="container">
		<?php dynamic_sidebar('billboard_area'); ?>
		</div>
	</div>
<?php endif; ?>
<main class="main">
	<div class="container">
		<div class="main-box">
			<div class="content">
				<?php if (have_posts()): ?>
					<div class="widget indeks">
						
					<div class="widget-author">
						<div class="aut-box">
							<div class="aut-image">
								<?php echo get_avatar( get_the_author_meta( 'ID' ), 70 ); ?>
							</div>
							<div class="aut-text">
								<h1 class="aut-name"><?php echo get_the_author(); ?></h1>
								<?php if(!empty(get_the_author_meta('url')) ||
								!empty(get_the_author_meta('facebook')) ||
								!empty(get_the_author_meta('twitter')) ||
								!empty(get_the_author_meta('instagram'))): ?>
									<div class="aut-share">
										<?php if(!empty(get_the_author_meta('url'))): ?>
											<a class="url" href="<?php echo get_the_author_meta('url'); ?>" target="_blank" rel="nofollow">
												<svg fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 0C397.4 0 512 114.6 512 256C512 397.4 397.4 512 256 512C114.6 512 0 397.4 0 256C0 114.6 114.6 0 256 0zM256 464C263.4 464 282.1 456.8 303.6 415.6C312.4 397.9 319.1 376.4 325.6 352H186.4C192 376.4 199.6 397.9 208.4 415.6C229 456.8 248.6 464 256 464zM178.5 304H333.5C335.1 288.7 336 272.6 336 256C336 239.4 335.1 223.3 333.5 208H178.5C176.9 223.3 176 239.4 176 256C176 272.6 176.9 288.7 178.5 304V304zM325.6 160C319.1 135.6 312.4 114.1 303.6 96.45C282.1 55.22 263.4 48 256 48C248.6 48 229 55.22 208.4 96.45C199.6 114.1 192 135.6 186.4 160H325.6zM381.8 208C383.2 223.5 384 239.6 384 256C384 272.4 383.2 288.5 381.8 304H458.4C462.1 288.6 464 272.5 464 256C464 239.5 462.1 223.4 458.4 208H381.8zM342.1 66.61C356.2 92.26 367.4 124.1 374.7 160H440.6C419.2 118.9 384.4 85.88 342.1 66.61zM169.9 66.61C127.6 85.88 92.84 118.9 71.43 160H137.3C144.6 124.1 155.8 92.26 169.9 66.61V66.61zM48 256C48 272.5 49.93 288.6 53.57 304H130.2C128.8 288.5 128 272.4 128 256C128 239.6 128.8 223.5 130.2 208H53.57C49.93 223.4 48 239.5 48 256zM440.6 352H374.7C367.4 387.9 356.2 419.7 342.1 445.4C384.4 426.1 419.2 393.1 440.6 352zM137.3 352H71.43C92.84 393.1 127.6 426.1 169.9 445.4C155.8 419.7 144.6 387.9 137.3 352V352z"/></svg>
											</a>
										<?php endif; ?>
										<?php if(!empty(get_the_author_meta('facebook'))): ?>
											<a class="facebook" href="<?php echo get_the_author_meta('facebook'); ?>" target="_blank" rel="nofollow">
												<svg fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><!--! Font Awesome Pro 6.2.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"></path></svg>
											</a>
										<?php endif; ?>
										<?php if(!empty(get_the_author_meta('twitter'))): ?>
											<a class="twitter" href="https://twitter.com/<?php echo get_the_author_meta('twitter'); ?>" target="_blank" rel="nofollow">
												<svg fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.2.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"></path></svg>
											</a>
										<?php endif; ?>
										<?php if(!empty(get_the_author_meta('instagram'))): ?>
											<a class="instagram" href="<?php echo get_the_author_meta('instagram'); ?>" target="_blank" rel="nofollow">
												<svg fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Pro 6.2.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path></svg>
											</a>
										<?php endif; ?>
									</div>
								<?php endif; ?>
							</div>
						</div>
						<?php if(!empty(get_the_author_meta('description'))): ?>
							<div class="desc-box"><?php echo get_the_author_meta('description'); ?></div>
						<?php endif; ?>
					</div>
						<div class="widget-content">
							<?php
							while (have_posts()): the_post();
               					$counter = get_post_meta( get_the_ID(), 'counter', true );
								echo '<div class="indeks-item media">
										<div class="indeks-image media-image">';
				                         if($counter["video"] != ""):
				                              echo  '<div class="video-time">' . $counter["video"]. '</div>';
				                         endif;
				                         if($counter["foto"] != ""):
				                              echo '<div class="foto-counter">' . $counter["foto"]. ' Foto</div>';
				                         endif;
										echo customthumbnail(get_the_ID(), 'image_198_114'). '
										</div>
										<div class="indeks-text">';
											if(!empty(labelcategory())):
												echo '<div class="indeks-category">' . labelcategory() . '</div>';
											endif;
											echo '<h2>
												<a href="' . get_permalink() . '" class="media-title">' . get_the_title() . '</a>
											</h2>
										<div class="indeks-date">' . get_the_date( get_option('date_format') ) . ', ' . get_the_time( get_option('time_format') ) . '</div>
										</div>
									</div>';
							endwhile; ?>
					 </div>
					<div class="widget-pagination">
						<div class="status">
							<div class="pagination-index">
								<a href="javascript:void(0)" class="trigger">Lihat lainnya</a>
							</div>
							<div class="loading">
								<svg class="td-loader__circle" viewBox="25 25 50 50">
									<circle class="td-loader__path" cx="50" cy="50" r="20" fill="none" stroke-width="4" stroke-miterlimit="10"></circle>
								</svg>
							</div>
							<div class="no-more">Artikel sudah termuat semua...</div>
						</div>
						<div class="pagination-index loadmore">
							<?php echo get_next_posts_link("Lihat lainnya"); ?>
						</div>
					</div>
				</div>
				<?php endif; ?>

			</div>
			<aside class="sidebar">
				<?php
				if (is_active_sidebar('sidebararchive_area')) :
					dynamic_sidebar('sidebararchive_area');
				endif;
				?>
				<?php get_template_part("template-parts/footer/index"); ?>
			</aside>
		</div>
	</div>
</main>
<?php get_template_part("template-parts/custom/ads-sticky-left"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-right"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-bottom"); ?>


