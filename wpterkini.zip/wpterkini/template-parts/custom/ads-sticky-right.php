<?php if (is_active_sidebar('sticky_ads_right')) : ?>
	<div class="ads-sticky ads-sticky-right">
		<?php dynamic_sidebar('sticky_ads_right'); ?>
	</div>
<?php endif;
?>