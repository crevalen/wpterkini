<?php if (is_active_sidebar('sticky_ads_bottom')) : ?>
	<div class="ads-sticky-bottom">
		<div class="btn-ads-close">Tutup Iklan
			<span class="ads-close-icon"></span>
		</div>
		<?php dynamic_sidebar('sticky_ads_bottom'); ?>
	</div>
<?php endif;
?>