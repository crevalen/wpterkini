<?php if (is_active_sidebar('sticky_ads_left')) : ?>
	<div class="ads-sticky ads-sticky-left">
		<?php dynamic_sidebar('sticky_ads_left'); ?>
	</div>
<?php endif;
?>