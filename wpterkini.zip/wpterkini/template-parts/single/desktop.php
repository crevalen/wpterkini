<?php if (is_active_sidebar('billboard_area')) : ?>
	<div class="billboard">
		<div class="container">
		<?php dynamic_sidebar('billboard_area'); ?>
		</div>
	</div>
<?php endif; ?>
<?php 
if (have_posts()):
while (have_posts()): the_post(); 
$tim = get_post_meta(get_the_ID(), 'tim', true );
?>
<main class="main">
	<div class="container">
		<div class="main-box">
			<div class="content">
				<div class="article">
					<div class="article-header">
						<div class="breadcrumbs">
							<ul>
								<li><a href="<?php echo home_url("/"); ?>">Beranda</a></li>
								<li><a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a></li>
							</ul>
						</div>
						<h1 class="post-title"><?php the_title(); ?></h1>
						<div class="post-meta"><a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>"><?php echo get_the_author(); ?></a> - <?php echo get_the_date( get_option('date_format') ); ?> <?php echo get_the_time( get_option('time_format') ); ?></div>
						<div class="post-more">
							<?php get_template_part("template-parts/custom/btnshare"); ?>
						</div>
					</div>

					<?php 
					if (has_post_format( array( 'gallery', 'image', 'video' ) )):
					else:
					    if ( true == get_theme_mod( 'featuredimageactivepos', false )): 
							if (has_post_thumbnail( get_the_ID() ) ): 
								$caption = get_post(get_post_thumbnail_id())->post_excerpt;
								?>
								<div class="article-featured">
									<figure>
										<div class="image-box">
										<a class="spotlight" data-description="<?php echo $caption; ?>" href="<?php echo get_the_post_thumbnail_url($post_id,'full'); ?>" >
											<div class="btn-viewbox"><button class="btn-biew"><i class="icon-expand"></i><span class="text-view">Perbesar</span></button></div>
											<?php 
											echo get_the_post_thumbnail( $post_id, 'image_656_369', array( 'class' => 'featured-image' ) );
											?>
											</a>	
										</div>
									<?php 
										if(!empty($caption)){ ?>
											<figcaption><?php echo $caption; ?></figcaption>
									<?php } ?>
									</figure>
								</div>
							<?php endif;
					    endif;  
					endif;
					?>

					<div class="article-body">
					<?php 
        				if (has_post_format( array( 'gallery', 'image', 'video' ) )):
        					else:
								if (is_active_sidebar('sticky_ads_post')) :?>
									<div class="article-adv">
										<div class="sticky-post">
										<?php
										dynamic_sidebar('sticky_ads_post');?>
										</div>
									</div>
									<?php
								endif;
								?>
						<?php endif; ?>
						<div class="post-body">
							<div class="post-article">
								<?php the_content(); ?>
							</div>
							<?php 
							global $page, $pages;
							if(count($pages) > 1): ?>
								<div class="pagination-post">
									<?php
										echo '<div class="paginationPostLabel">Halaman</div><div class="paginationPostNum">';
										wp_link_pages( 'before=<div class="paginationPostLink">&after=</div>'); 
										wp_link_pages( 'before=<div class="paginationPostNav">&after=</div>&nextpagelink=<span class="btn-next">Selanjutnya</span>&next_or_number=next&previouspagelink='); 
										echo '</div>';
									?>
								</div>
							<?php endif;
							?>
				    	    <?php if(has_tag()): ?>
							<div class="post-tag">
								<div class="tag-label">Tag Terkait:</div>
								<div class="tag-box">
									<?php the_tags( '<ul><li>', '</li><li>', '</li></ul>' ); ?>
								</div>
							</div>
							<?php endif; ?>

							<div class="footer-share">
								<?php get_template_part("template-parts/custom/btnshare"); ?>
							</div>
							<?php if ( true == get_theme_mod( 'timredaksiactive', true )) : ?>
							<div class="redaksi">
								<div class="redaksi-header">
									<div class="redaksi-avatar">
										<div class="redaksi-avatar-box">
											<?php if ( true == get_theme_mod( 'timredaksipenulis', true )) : ?>
												<div class="image-ava"><?php echo get_avatar( get_the_author_meta( 'ID' ), 24 ); ?></div>
										    <?php endif;  ?>
											<?php if ( true == get_theme_mod( 'timredaksieditor', true )) : ?>
												<?php if(!empty($tim['editor']) && $tim['editor'] != "-1"): ?>
													<div class="image-ava">
														<?php echo get_avatar( $tim['editor'], 24 ); ?></div>
												<?php endif; ?>
										    <?php endif;  ?>
											<?php if ( true == get_theme_mod( 'timredaksireporter', true )) : ?>
												<?php if(!empty($tim['reporter']) && $tim['reporter'] != "-1"): ?>
													<div class="image-ava">
														<?php echo get_avatar( $tim['reporter'], 24 ); ?></div>
												<?php endif; ?>
										    <?php endif;  ?>
										</div>
									</div>
									<button class="btn-redaksi"><i class="icon-arrow"></i><span class="label-btn">
										<?php 
										if ( "" != (get_theme_mod( 'tombolredaksititle' ))) :
											echo get_theme_mod( 'tombolredaksititle' );
										else:
											echo 'Tim Redaksi';
										endif;
										?>
									</span></button>
								</div>
								<div class="redaksi-content hide">
									<div class="redaksi-content-box">
										<?php if ( true == get_theme_mod( 'timredaksipenulis', true )) : ?>
										<div class="author-item">
											<div class="author-image">
												<a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>">
													<?php echo get_avatar( get_the_author_meta( 'ID' ), 48 ); ?>
												</a>
											</div>
												<div class="author-text">
												<a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>">
													<div class="author-name">
														<?php echo get_the_author(); ?>
															<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20" style="enable-background:new 0 0 20 20;" xml:space="preserve"> <g id="Icon"> <g id="verified"> <path id="Shape" class="st0" fill="currentColor" d="M18.6,9l-0.3-0.3c-0.4-0.3-0.5-0.9-0.3-1.3l0.2-0.4c0.3-0.7-0.1-1.4-0.8-1.6l-0.5-0.1 c-0.5-0.1-0.8-0.6-0.8-1.1V3.7c0-0.7-0.7-1.2-1.4-1.1l-0.5,0.1c-0.5,0.1-1-0.1-1.2-0.6l-0.2-0.4c-0.3-0.6-1.1-0.8-1.7-0.4 l-0.4,0.3c-0.4,0.3-1,0.3-1.4,0L9,1.2C8.4,0.8,7.6,1,7.3,1.6L7.1,2C6.8,2.5,6.3,2.7,5.8,2.6L5.3,2.5C4.6,2.4,4,2.9,3.9,3.6l0,0.5 c0,0.5-0.4,0.9-0.8,1.1L2.6,5.3C2,5.5,1.6,6.2,1.9,6.9l0.2,0.4c0.2,0.5,0.1,1-0.3,1.3L1.4,8.9c-0.5,0.5-0.5,1.3,0,1.8L1.7,11 c0.4,0.3,0.5,0.9,0.3,1.3l-0.2,0.4c-0.3,0.7,0.1,1.4,0.8,1.6l0.5,0.1c0.5,0.1,0.8,0.6,0.8,1.1l0,0.5c0,0.7,0.7,1.2,1.4,1.1L5.8,17 c0.5-0.1,1,0.1,1.2,0.6l0.2,0.4c0.3,0.6,1.1,0.8,1.7,0.4l0.4-0.3c0.4-0.3,1-0.3,1.4,0l0.4,0.3c0.6,0.4,1.4,0.2,1.7-0.4l0.2-0.4 c0.3-0.5,0.7-0.7,1.2-0.6l0.5,0.1c0.7,0.1,1.3-0.4,1.4-1.1l0-0.5c0-0.5,0.4-0.9,0.8-1.1l0.5-0.1c0.7-0.2,1-0.9,0.8-1.6L18,12.3 c-0.2-0.5-0.1-1,0.3-1.3l0.3-0.3C19.1,10.3,19.1,9.4,18.6,9L18.6,9z" /> <path id="Shape_1_" class="st1" fill="#fff" d="M4.3,9.5L4.3,9.5C4.8,9,5.5,9,5.9,9.5l2.4,2.4l5.5-5.5c0.4-0.4,1.1-0.4,1.6,0l0,0 c0.4,0.4,0.4,1.1,0,1.6L9,14.2c-0.4,0.4-1.1,0.4-1.6,0L4.3,11C3.9,10.6,3.9,9.9,4.3,9.5L4.3,9.5z" /> </g> </g> </svg>
													</div>
													<div class="author-role">Penulis</div>
												</a>
												</div>
										</div>
									    <?php endif;  ?>
										<?php if ( true == get_theme_mod( 'timredaksieditor', true )) : ?>
											<?php if(!empty($tim['editor']) && $tim['editor'] != "-1"): ?>
											<div class="author-item">
												<div class="author-image"><?php echo get_avatar( $tim['editor'], 48 ); ?></div>
												<div class="author-text">
													<div class="author-name">
														<?php echo get_the_author_meta('display_name', $tim['editor']); ?> 
															<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20" style="enable-background:new 0 0 20 20;" xml:space="preserve"> <g id="Icon"> <g id="verified"> <path id="Shape" class="st0" fill="currentColor" d="M18.6,9l-0.3-0.3c-0.4-0.3-0.5-0.9-0.3-1.3l0.2-0.4c0.3-0.7-0.1-1.4-0.8-1.6l-0.5-0.1 c-0.5-0.1-0.8-0.6-0.8-1.1V3.7c0-0.7-0.7-1.2-1.4-1.1l-0.5,0.1c-0.5,0.1-1-0.1-1.2-0.6l-0.2-0.4c-0.3-0.6-1.1-0.8-1.7-0.4 l-0.4,0.3c-0.4,0.3-1,0.3-1.4,0L9,1.2C8.4,0.8,7.6,1,7.3,1.6L7.1,2C6.8,2.5,6.3,2.7,5.8,2.6L5.3,2.5C4.6,2.4,4,2.9,3.9,3.6l0,0.5 c0,0.5-0.4,0.9-0.8,1.1L2.6,5.3C2,5.5,1.6,6.2,1.9,6.9l0.2,0.4c0.2,0.5,0.1,1-0.3,1.3L1.4,8.9c-0.5,0.5-0.5,1.3,0,1.8L1.7,11 c0.4,0.3,0.5,0.9,0.3,1.3l-0.2,0.4c-0.3,0.7,0.1,1.4,0.8,1.6l0.5,0.1c0.5,0.1,0.8,0.6,0.8,1.1l0,0.5c0,0.7,0.7,1.2,1.4,1.1L5.8,17 c0.5-0.1,1,0.1,1.2,0.6l0.2,0.4c0.3,0.6,1.1,0.8,1.7,0.4l0.4-0.3c0.4-0.3,1-0.3,1.4,0l0.4,0.3c0.6,0.4,1.4,0.2,1.7-0.4l0.2-0.4 c0.3-0.5,0.7-0.7,1.2-0.6l0.5,0.1c0.7,0.1,1.3-0.4,1.4-1.1l0-0.5c0-0.5,0.4-0.9,0.8-1.1l0.5-0.1c0.7-0.2,1-0.9,0.8-1.6L18,12.3 c-0.2-0.5-0.1-1,0.3-1.3l0.3-0.3C19.1,10.3,19.1,9.4,18.6,9L18.6,9z" /> <path id="Shape_1_" class="st1" fill="#fff" d="M4.3,9.5L4.3,9.5C4.8,9,5.5,9,5.9,9.5l2.4,2.4l5.5-5.5c0.4-0.4,1.1-0.4,1.6,0l0,0 c0.4,0.4,0.4,1.1,0,1.6L9,14.2c-0.4,0.4-1.1,0.4-1.6,0L4.3,11C3.9,10.6,3.9,9.9,4.3,9.5L4.3,9.5z" /> </g> </g> </svg>
													</div>
													<div class="author-role">Editor</div>
												</div>
											</div>
											<?php endif; ?>
									    <?php endif;  ?>
										<?php if ( true == get_theme_mod( 'timredaksireporter', true )) : ?>
											<?php if(!empty($tim['reporter']) && $tim['reporter'] != "-1"): ?>
											<div class="author-item">
												<div class="author-image"><?php echo get_avatar( $tim['reporter'], 48 ); ?></div>
												<div class="author-text">
													<div class="author-name">
														<?php echo get_the_author_meta('display_name', $tim['reporter']); ?>
															<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20" style="enable-background:new 0 0 20 20;" xml:space="preserve"> <g id="Icon"> <g id="verified"> <path id="Shape" class="st0" fill="currentColor" d="M18.6,9l-0.3-0.3c-0.4-0.3-0.5-0.9-0.3-1.3l0.2-0.4c0.3-0.7-0.1-1.4-0.8-1.6l-0.5-0.1 c-0.5-0.1-0.8-0.6-0.8-1.1V3.7c0-0.7-0.7-1.2-1.4-1.1l-0.5,0.1c-0.5,0.1-1-0.1-1.2-0.6l-0.2-0.4c-0.3-0.6-1.1-0.8-1.7-0.4 l-0.4,0.3c-0.4,0.3-1,0.3-1.4,0L9,1.2C8.4,0.8,7.6,1,7.3,1.6L7.1,2C6.8,2.5,6.3,2.7,5.8,2.6L5.3,2.5C4.6,2.4,4,2.9,3.9,3.6l0,0.5 c0,0.5-0.4,0.9-0.8,1.1L2.6,5.3C2,5.5,1.6,6.2,1.9,6.9l0.2,0.4c0.2,0.5,0.1,1-0.3,1.3L1.4,8.9c-0.5,0.5-0.5,1.3,0,1.8L1.7,11 c0.4,0.3,0.5,0.9,0.3,1.3l-0.2,0.4c-0.3,0.7,0.1,1.4,0.8,1.6l0.5,0.1c0.5,0.1,0.8,0.6,0.8,1.1l0,0.5c0,0.7,0.7,1.2,1.4,1.1L5.8,17 c0.5-0.1,1,0.1,1.2,0.6l0.2,0.4c0.3,0.6,1.1,0.8,1.7,0.4l0.4-0.3c0.4-0.3,1-0.3,1.4,0l0.4,0.3c0.6,0.4,1.4,0.2,1.7-0.4l0.2-0.4 c0.3-0.5,0.7-0.7,1.2-0.6l0.5,0.1c0.7,0.1,1.3-0.4,1.4-1.1l0-0.5c0-0.5,0.4-0.9,0.8-1.1l0.5-0.1c0.7-0.2,1-0.9,0.8-1.6L18,12.3 c-0.2-0.5-0.1-1,0.3-1.3l0.3-0.3C19.1,10.3,19.1,9.4,18.6,9L18.6,9z" /> <path id="Shape_1_" class="st1" fill="#fff" d="M4.3,9.5L4.3,9.5C4.8,9,5.5,9,5.9,9.5l2.4,2.4l5.5-5.5c0.4-0.4,1.1-0.4,1.6,0l0,0 c0.4,0.4,0.4,1.1,0,1.6L9,14.2c-0.4,0.4-1.1,0.4-1.6,0L4.3,11C3.9,10.6,3.9,9.9,4.3,9.5L4.3,9.5z" /> </g> </g> </svg>
													</div>
													<div class="author-role">Reporter</div>
												</div>
											</div>
											<?php endif; ?>
									    <?php endif;  ?>
									</div>
								</div>
							</div>
							<?php endif;  ?>
						</div>
					</div>
					<?php 
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;
					 ?>
					<?php
					if (is_active_sidebar('afterpos_area')) : ?>
						<div class="article-footer">
							<?php dynamic_sidebar('afterpos_area'); ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
			<aside class="sidebar">
				<?php
				if (is_active_sidebar('sidebarpos_area')) :
					dynamic_sidebar('sidebarpos_area');
				endif;
				?>
				<?php get_template_part("template-parts/footer/index"); ?>
			</aside>
		</div>
	</div>
</main>
<?php
endwhile;
endif; ?>
<?php get_template_part("template-parts/custom/ads-sticky-left"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-right"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-bottom"); ?>