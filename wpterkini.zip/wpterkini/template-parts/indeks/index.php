<?php 
if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
    require "amp.php";
}elseif (wp_is_mobile()) {
    require "mobile.php";
}else{
    require "desktop.php";
}
?>