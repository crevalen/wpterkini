<?php 
if (is_active_sidebar('parallax_mobile')) : ?>
<div class="billboard parallax">
	<?php dynamic_sidebar('parallax_mobile'); ?>	
</div>
<?php 
endif;
?>
<header class="header">
	<div class="container">
		<div class="header-box">
			<div class="header-brand">
				<div class="menu-bar">
					<div class="btn-header">
						<span></span>
						<span></span>
						<span></span>
					</div>
				</div>
				<div class="brand-image">
					<?php 
						if (function_exists('the_custom_logo')) :
							if(has_custom_logo()) :
								echo the_custom_logo();
							endif;
						endif;
						$blogInfo = get_bloginfo('name');
						if (!empty($blogInfo)) : 
							if (is_front_page() && is_home()) :
								brand_h1();
								else :
								brand_p();
							endif;
						endif;
						$description = get_bloginfo( 'description', 'display' );
						if ($description || is_customize_preview()) :
							brand_description($description);
						endif;
					?>
				</div>
			</div>
			<div class="header-more">
				<div class="header-mode">
					<div class="mode">
						<div class="dark">
							<svg width='24px' height='24px' viewBox='0 0 24 24' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'><g id='moon' stroke='none' stroke-width='1' fill='none' fill-rule='evenodd' stroke-linecap='round' stroke-linejoin='round'><g id='Group' transform='translate(-0.000000, -0.000000)' stroke='currentColor' stroke-width='1.6'><path d='M21.0000001,12.7900001 C20.5623509,17.5258085 16.5155206,21.1036352 11.7617765,20.9575684 C7.00803243,20.8115016 3.1884985,16.9919677 3.04243172,12.2382236 C2.89636495,7.48447951 6.47419162,3.43764924 11.21,3.00000001 C9.15036197,5.78645174 9.43925663,9.66045323 11.8894017,12.1105984 C14.3395469,14.5607435 18.2135484,14.8496381 21.0000001,12.7900001 L21.0000001,12.7900001 Z' id='Path'></path></g></g></svg>
						</div>
						<div class="light hide">
							<svg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'><path d='M12 17C14.7614 17 17 14.7614 17 12C17 9.23858 14.7614 7 12 7C9.23858 7 7 9.23858 7 12C7 14.7614 9.23858 17 12 17Z' stroke='currentColor' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/><path d='M12 1V3' stroke='currentColor' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/><path d='M12 21V23' stroke='currentColor' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/><path d='M4.22 4.22L5.64 5.64' stroke='currentColor' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/><path d='M18.36 18.36L19.78 19.78' stroke='currentColor' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/><path d='M1 12H3' stroke='currentColor' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/><path d='M21 12H23' stroke='currentColor' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/><path d='M4.22 19.78L5.64 18.36' stroke='currentColor' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/><path d='M18.36 5.64L19.78 4.22' stroke='currentColor' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/></svg>

						</div>
					</div>
				</div>
				<div class="header-search">
					<div class="search-icon">
						<svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g id="search" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round"><g transform="translate(3.000000, 3.000000)" stroke="currentColor" stroke-width="1.5"><circle id="Oval" cx="7.5" cy="7.5" r="7.5"></circle><path d="M18,18 L12.8,12.8" id="Shape"></path></g></g></svg>
					</div>
				</div>
			</div>
		</div>
		<?php if ( has_nav_menu( 'mobile_menu' ) ) : ?>
		<nav class="navigation">
			<div class="mobile-menu">
		    <?php mobile_menu(); ?>
			</div>
		</nav>
		<?php endif; ?>
	</div>
</header>
<div class="header-search-popup">
	<form action="<?php echo home_url('/'); ?>">
		<input type="text" class="search-input" name="s" placeholder="Cari berita disini..." value="<?php the_search_query(); ?>" maxlength="50" autocomplete="off">
		<input type="hidden" name="post_type" value="post" />
		<div class="search-close">
			<svg fill="currentColor" width="32px" height="32px" viewBox="0 0 32 32" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M 7.21875 5.78125 L 5.78125 7.21875 L 14.5625 16 L 5.78125 24.78125 L 7.21875 26.21875 L 16 17.4375 L 24.78125 26.21875 L 26.21875 24.78125 L 17.4375 16 L 26.21875 7.21875 L 24.78125 5.78125 L 16 14.5625 Z"></path></svg>
		</div>
	</form>
</div>
<div class="search-transparent"></div>
<div class="sidebarmenu">
	<div class="sidebarmenu-box">
		<?php if (is_active_sidebar('sidebar_menu')) : ?>
			<div class="custom-menu">
			<?php dynamic_sidebar('sidebar_menu'); ?>
			</div>
		<?php endif; ?>
		<?php if ( has_nav_menu( 'network_menu' ) ) : ?>
			<div class="network">
		    <?php network_menu(); ?>
			</div>
		<?php endif; ?>
		<?php if ( has_nav_menu( 'social_menu' ) ) : ?>
			<div class="social">
		    <?php social_menu(); ?>
			</div>
		<?php endif; ?>
	</div>
</div>