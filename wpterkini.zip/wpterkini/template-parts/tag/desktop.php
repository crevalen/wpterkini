<?php if (is_active_sidebar('billboard_area')) : ?>
	<div class="billboard">
		<div class="container">
		<?php dynamic_sidebar('billboard_area'); ?>
		</div>
	</div>
<?php endif; ?>
<main class="main">
	<div class="container">
		<div class="main-box">
			<div class="content">
				<?php if (have_posts()): ?>
					<div class="widget indeks">
						<div class="widget-desc">
							<h1 class="search-title">#<?php echo single_tag_title(); ?></h1>
						</div>
						<div class="widget-content">
							<?php
							while (have_posts()): the_post();
               					$counter = get_post_meta( get_the_ID(), 'counter', true );
								echo '<div class="indeks-item media">
										<div class="indeks-image media-image">';
				                         if($counter["video"] != ""):
				                              echo  '<div class="video-time">' . $counter["video"]. '</div>';
				                         endif;
				                         if($counter["foto"] != ""):
				                              echo '<div class="foto-counter">' . $counter["foto"]. ' Foto</div>';
				                         endif;
										echo customthumbnail(get_the_ID(), 'image_198_114'). '
										</div>
										<div class="indeks-text">';
											if(!empty(labelcategory())):
												echo '<div class="indeks-category">' . labelcategory() . '</div>';
											endif;
											echo '<h2>
												<a href="' . get_permalink() . '" class="media-title">' . get_the_title() . '</a>
											</h2>
										<div class="indeks-date">' . get_the_date( get_option('date_format') ) . ', ' . get_the_time( get_option('time_format') ) . '</div>
										</div>
									</div>';
							endwhile; ?>
					 </div>
					<div class="widget-pagination">
						<div class="status">
							<div class="pagination-index">
								<a href="javascript:void(0)" class="trigger">Lihat lainnya</a>
							</div>
							<div class="loading">
								<svg class="td-loader__circle" viewBox="25 25 50 50">
									<circle class="td-loader__path" cx="50" cy="50" r="20" fill="none" stroke-width="4" stroke-miterlimit="10"></circle>
								</svg>
							</div>
							<div class="no-more">Artikel sudah termuat semua...</div>
						</div>
						<div class="pagination-index loadmore">
							<?php echo get_next_posts_link("Lihat lainnya"); ?>
						</div>
					</div>
				</div>
				<?php endif; ?>

			</div>
			<aside class="sidebar">
				<?php
				if (is_active_sidebar('sidebararchive_area')) :
					dynamic_sidebar('sidebararchive_area');
				endif;
				?>
				<?php get_template_part("template-parts/footer/index"); ?>
			</aside>
		</div>
	</div>
</main>
<?php get_template_part("template-parts/custom/ads-sticky-left"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-right"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-bottom"); ?>


