<?php if (is_active_sidebar('billboard_area')) : ?>
	<div class="billboard">
		<div class="container">
		<?php dynamic_sidebar('billboard_area'); ?>
		</div>
	</div>
<?php endif; ?>
<main class="main">
	<div class="container">
		<div class="main-box">
			<div class="content">
				<?php 
				$args = array(
					'post_type' => 'post',
					'post_status' => 'publish'
				);
				$my_query = new WP_Query( $args );
				if ( $my_query->have_posts() ): ?>
					<div class="widget indeks">
						<div class="widget-desc error-desc">
							<svg fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path d="M 16 3 C 8.832031 3 3 8.832031 3 16 C 3 23.167969 8.832031 29 16 29 C 23.167969 29 29 23.167969 29 16 C 29 8.832031 23.167969 3 16 3 Z M 16 5 C 22.085938 5 27 9.914063 27 16 C 27 22.085938 22.085938 27 16 27 C 9.914063 27 5 22.085938 5 16 C 5 9.914063 9.914063 5 16 5 Z M 15 10 L 15 12 L 17 12 L 17 10 Z M 15 14 L 15 22 L 17 22 L 17 14 Z"></path></svg>
							<div class="error-box">
								<h1>Halaman tidak ditemukan</h1>
								<p>Opps! Maaf, halaman tidak tersedia. Coba periksa kembali URL</p>
							</div>
						</div>
						<div class="widget-header">
							<h3 class="widget-title">Indeks</h3>
						</div>
						<div class="widget-content">
							<?php 
							while ( $my_query->have_posts() ) :
								$my_query->the_post(); 
			                    $counter = get_post_meta( get_the_ID(), 'counter', true );
								echo '<div class="indeks-item media">
										<div class="indeks-image media-image">';
				                         if(!empty($counter["video"])):
				                              echo  '<div class="video-time">' . $counter["video"]. '</div>';
				                         endif;
				                         if(!empty($counter["foto"])):
				                              echo '<div class="foto-counter">' . $counter["foto"]. ' Foto</div>';
				                         endif;

										echo customthumbnail(get_the_ID(), 'image_198_114'). '
										</div>
										<div class="indeks-text">';
											if(!empty(labelcategory())):
												echo '<div class="indeks-category">' . labelcategory() . '</div>';
											endif;
											echo '<h2>
												<a href="' . get_permalink() . '" class="media-title">' . get_the_title() . '</a>
											</h2>
										<div class="indeks-date">' . get_the_date( get_option('date_format') ) . ', ' . get_the_time( get_option('time_format') ) . '</div>
										</div>
									</div>';
							endwhile; ?>
					 </div>
				</div>
				<?php endif; ?>

			</div>
			<aside class="sidebar">
				<?php
				if (is_active_sidebar('sidebararchive_area')) :
					dynamic_sidebar('sidebararchive_area');
				endif;
				?>
				<?php get_template_part("template-parts/footer/index"); ?>
			</aside>
		</div>
	</div>
</main>
<?php get_template_part("template-parts/custom/ads-sticky-left"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-right"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-bottom"); ?>


