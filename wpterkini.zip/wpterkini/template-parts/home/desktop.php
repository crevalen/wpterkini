<?php if (is_active_sidebar('billboard_area')) : ?>
	<div class="billboard">
		<div class="container">
		<?php dynamic_sidebar('billboard_area'); ?>
		</div>
	</div>
<?php endif; ?>
<main class="main">
	<div class="container">
		<div class="main-box">
			<div class="content">
				<?php
				if (is_active_sidebar('homepage_area')) :
					dynamic_sidebar('homepage_area');
				endif;
				?>
			</div>
			<aside class="sidebar">
				<?php
				if (is_active_sidebar('sidebar_area')) :
					dynamic_sidebar('sidebar_area');
				endif;
				?>
				<?php get_template_part("template-parts/footer/index"); ?>
			</aside>
		</div>
	</div>
</main>
<?php get_template_part("template-parts/custom/ads-sticky-left"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-right"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-bottom"); ?>


