<?php if (is_active_sidebar('billboard_area')) : ?>
	<div class="billboard">
		<div class="container">
		<?php dynamic_sidebar('billboard_area'); ?>
		</div>
	</div>
<?php endif; ?>
<main class="main">
	<div class="container">
		<div class="main-box">
			<div class="content">
					<div class="widget indeks">
						<div class="widget-header">
							<h3 class="widget-title"><?php the_title(); ?></h3>
						</div>
					<?php the_content(); ?>
				</div>

			</div>
			<aside class="sidebar">
				<?php
				if (is_active_sidebar('sidebararchive_area')) :
					dynamic_sidebar('sidebararchive_area');
				endif;
				?>
				<?php get_template_part("template-parts/footer/index"); ?>
			</aside>
		</div>
	</div>
</main>
<?php get_template_part("template-parts/custom/ads-sticky-left"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-right"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-bottom"); ?>


