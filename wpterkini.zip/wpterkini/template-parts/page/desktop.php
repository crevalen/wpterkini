<?php if (is_active_sidebar('billboard_area')) : ?>
	<div class="billboard">
		<div class="container">
		<?php dynamic_sidebar('billboard_area'); ?>
		</div>
	</div>
<?php endif; ?>
<?php 
if (have_posts()):
while (have_posts()): the_post(); 
?>
<main class="main">
	<div class="container">
		<div class="main-box">
			<div class="content">
				<div class="article">
					<div class="article-header">
						<h1 class="post-title"><?php the_title(); ?></h1>
					</div>

					<?php if ( true == get_theme_mod( 'featuredimageactivepage', false )) : 
						if ( "" != (get_theme_mod( 'categoryfeaturedimagea' ))) :
						else:
						endif;
						$textcat = get_theme_mod( 'categoryfeaturedimagea' );
						$splittedcat = explode(",", $textcat);
						$arrcat = "'" . implode("', '", $splittedcat) ."'";
						$category_detail=get_the_category($post_id);
						$datafeaturedimage = "array(". $arrcat .")";
						$parsed = eval("return " . $datafeaturedimage . ";");
						$arrcount = count($parsed);

						$ck = 0;
						$hasil = 0;
						foreach($category_detail as $cd){
							$aprseslug = strval($cd->slug);
							for ($i=0; $i < $arrcount; $i++) { 
								$hasparse = strval($parsed[$i]);
								if($aprseslug == $hasparse){
									$ck = 1;
									break;
								}else{
									$ck = 0;
								}
							}
							if($ck == 1){
								$hasil = 1 ;
							}else{
								$hasil = "";
							}
						}
						if(empty($hasil) || $hasil == ""){
							if (has_post_thumbnail( get_the_ID() ) ): 
								?>
								<div class="article-featured">
									<figure>
										<div class="image-box">
										<a data-fslightbox="gallery" href="<?php echo get_the_post_thumbnail_url($post_id,'full'); ?>" >
											<?php 
											echo get_the_post_thumbnail( $post_id, 'image_656_369', array( 'class' => 'featured-image' ) );
											$caption = get_post(get_post_thumbnail_id())->post_excerpt;
											?>
											</a>	
										</div>
									<?php 
										if(!empty($caption)){ ?>
											<figcaption><?php echo $caption; ?></figcaption>
									<?php } ?>
									</figure>
								</div>
							<?php endif;
						}
					endif;  ?>

					<div class="article-body">
						<div class="post-body">
							<div class="post-article">
								<?php the_content(); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<aside class="sidebar">
				<?php
				if (is_active_sidebar('sidebararchive_area')) :
					dynamic_sidebar('sidebararchive_area');
				endif;
				?>
				<?php get_template_part("template-parts/footer/index"); ?>
			</aside>
		</div>
	</div>
</main>
<?php
endwhile;
endif; ?>
<?php get_template_part("template-parts/custom/ads-sticky-left"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-right"); ?>
<?php get_template_part("template-parts/custom/ads-sticky-bottom"); ?>