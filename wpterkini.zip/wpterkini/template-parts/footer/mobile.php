<footer class="widget footer">
	<?php if (is_active_sidebar('footer_top')) : ?>
		<div class="footer-top">
		<?php dynamic_sidebar('footer_top'); ?>
		</div>
	<?php endif; ?>
	<?php if (is_active_sidebar('footer_bottom')) : ?>
		<div class="footer-bottom">
		<?php dynamic_sidebar('footer_bottom'); ?>
		</div>
	<?php endif; ?>
</footer>