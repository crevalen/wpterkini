<?php if (is_active_sidebar('billboard_area')) : ?>
	<div class="billboard">
		<div class="container">
		<?php dynamic_sidebar('billboard_area'); ?>
		</div>
	</div>
<?php endif; ?>
<main class="main">
	<div class="container">
		<div class="main-box">
			<div class="content">
				<?php if (have_posts()):
					$counter = 0;
					$num = 1;
					$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
					while (have_posts()): the_post();
						$big; 
						$small;
						$counter++; 
						$no = $num++;
               			$counter = get_post_meta( get_the_ID(), 'counter', true );
						if(1 == $paged) {
							if($no == 1):
							$big .= '<div class="widget headline">
									<div class="widget-content">
										<div class="headline-big media">
											<div class="headline-item">
												<div class="headline-image media-image">
												<div class="widget-header">
												<h3 class="widget-title">' . single_tag_title("", false) . '</h3>
											</div>';
				                         if($counter["video"] != ""):
				                              $big .= '<div class="video-time">' . $counter["video"]. '</div>';
				                         endif;

				                         if($counter["foto"] != ""):
				                              $big .= '<div class="foto-counter">' . $counter["foto"]. ' Foto</div>';
				                         endif;
											$big .= customthumbnail(get_the_ID(), 'image_656_369') . '
												</div>
												<div class="headline-text">
												';
										$big .= '<h2><a href="' . get_permalink() . '" class="media-title">' . get_the_title() . '</a></h2><div class="indeks-meta">';
											if(!empty(labelcategory())):
												$big .= '<div class="indeks-category">' . labelcategory() . '</div>';
											endif;
										$big .= '<div class="indeks-date">' . get_the_date( get_option('date_format') ) . ', ' . get_the_time( get_option('time_format') ) . '</div></div>
											</div>
											</div>
										</div>
										
									</div>
								</div>';
							else:
								$small .= '<div class="indeks-item media">
										<div class="indeks-image media-image">';
				                         if($counter["video"] != ""):
				                              $small .= '<div class="video-time"></div>';
				                         endif;
				                         if($counter["foto"] != ""):
				                              $small .= '<div class="foto-counter"></div>';
				                         endif;

										$small .= customthumbnail(get_the_ID(), 'thumbnail'). '
										</div>
										<div class="indeks-text">';
											$small .= '<h2>
												<a href="' . get_permalink() . '" class="media-title">' . get_the_title() . '</a>
											</h2><div class="indeks-meta">';
											if(!empty(labelcategory())):
												$small .= '<div class="indeks-category">' . labelcategory() . '</div>';
											endif;
										$small .= '<div class="indeks-date">' . get_the_date( get_option('date_format') ) . ', ' . get_the_time( get_option('time_format') ) . '</div></div>
										</div>
									</div>';
							endif;
						}else{

							$small .= '<div class="indeks-item media">
									<div class="indeks-image media-image">';
				                         if($counter["video"] != ""):
				                              $small .= '<div class="video-time"></div>';
				                         endif;
				                         if($counter["foto"] != ""):
				                              $small .= '<div class="foto-counter"></div>';
				                         endif;
										$small .= customthumbnail(get_the_ID(), 'thumbnail'). '
									</div>
										<div class="indeks-text">';
											$small .= '<h2>
												<a href="' . get_permalink() . '" class="media-title">' . get_the_title() . '</a>
											</h2><div class="indeks-meta">';
											if(!empty(labelcategory())):
												$small .= '<div class="indeks-category">' . labelcategory() . '</div>';
											endif;
										$small .= '<div class="indeks-date">' . get_the_date( get_option('date_format') ) . ', ' . get_the_time( get_option('time_format') ) . '</div></div>
										</div>
								</div>';
						}
					endwhile; ?>
				<?php 
				if(1 == $paged) {
					if($counter == 1):
						echo $big;
					endif;
					if($counter > 1):
						echo $big;
						?>
						<div class="widget indeks">
							<div class="widget-content">
								<?php echo $small; ?>
							</div>

							<div class="widget-pagination">
								<div class="status">
									<div class="pagination-index">
										<a href="javascript:void(0)" class="trigger">Lihat lainnya</a>
									</div>
									<div class="loading">
										<svg class="td-loader__circle" viewBox="25 25 50 50">
											<circle class="td-loader__path" cx="50" cy="50" r="20" fill="none" stroke-width="4" stroke-miterlimit="10"></circle>
										</svg>
									</div>
									<div class="no-more">Artikel sudah termuat semua...</div>
								</div>
								<div class="pagination-index loadmore">
									<?php echo get_next_posts_link("Lihat lainnya"); ?>
								</div>
							</div>
						</div>
						<?php 
						endif;
				}else{
					?>
					<div class="widget indeks">
						<div class="widget-content">
							<?php echo $small; ?>
						</div>

						<div class="widget-pagination">
							<div class="status">
								<div class="pagination-index">
									<a href="javascript:void(0)" class="trigger">Lihat lainnya</a>
								</div>
								<div class="loading">
									<svg class="td-loader__circle" viewBox="25 25 50 50">
										<circle class="td-loader__path" cx="50" cy="50" r="20" fill="none" stroke-width="4" stroke-miterlimit="10"></circle>
									</svg>
								</div>
								<div class="no-more">Artikel sudah termuat semua...</div>
							</div>
							<div class="pagination-index loadmore">
								<?php echo get_next_posts_link("Lihat lainnya"); ?>
							</div>
						</div>
					</div>
					<?php 
				}
				endif; ?>

			</div>
			<aside class="sidebar">
				<?php
				if (is_active_sidebar('sidebararchive_area')) :
					dynamic_sidebar('sidebararchive_area');
				endif;
				?>
				<?php get_template_part("template-parts/footer/index"); ?>
			</aside>
		</div>
	</div>
</main>
<?php get_template_part("template-parts/custom/ads-sticky-bottom"); ?>


