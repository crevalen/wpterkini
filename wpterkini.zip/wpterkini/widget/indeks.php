<?php
function indeksViewDesktop($title, $after, $time, $indeks, $txtindeks, $jml){
	$gettime = $time;
	preg_match("/\[(.*?)]/", $gettime, $zona);
	$datazona = $zona[1];
	$formattime = str_replace("[" . $zona[1] . "]", "", $time);

	$args = array(
		'post_type' => 'post',
		'post_status' => 'publish',
      	'offset' => $after - 1,
		'posts_per_page'=> $jml
	);
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
		<div class="widget indeks">
			<?php if(!empty($title)): ?>
			<div class="widget-header">
				<h3 class="widget-title"><?php echo $title; ?></h3>
			</div>
			<?php endif; ?>
			<div class="widget-content">
				<?php 
				while ( $my_query->have_posts() ) {
					$my_query->the_post(); 
                    $counter = get_post_meta( get_the_ID(), 'counter', true ); ?>
						<div class="indeks-item media">
							<div class="indeks-image media-image">
								<?php if($counter["video"] != ""): ?>
									<div class="video-time"><?php echo $counter["video"]; ?></div>
								<?php endif; ?>
		                         <?php if($counter["foto"] != ""): ?>
		                              <div class="foto-counter"><?php echo $counter["foto"]; ?> Foto</div>
		                         <?php endif; ?>
								<?php echo customthumbnail(get_the_ID(), 'image_198_114'); ?>
							</div>
							<div class="indeks-text">
								<?php if(!empty(labelcategory())): ?>
									<div class="indeks-category"><?php echo labelcategory(); ?></div>
								<?php endif; ?>
								<h2>
									<a href="<?php echo get_permalink(); ?>" class="media-title"><?php echo get_the_title(); ?></a>
								</h2>
								<div class="indeks-date"><?php echo gettime($formattime); ?> <?php echo $datazona; ?></div>
							</div>
						</div>
					<?php
				} wp_reset_postdata();
				?>
			</div>
			<?php if(!empty($indeks)): ?>
			<div class="widget-pagination">
				<div class="pagination-index">
					<a href="<?php echo $indeks; ?>"><?php echo $txtindeks; ?></a>
				</div>
			</div>
			<?php endif; ?>
		</div>
	<?php
	endif;
}
function indeksViewMobile($title, $after, $time, $indeks, $txtindeks, $jml){
	$gettime = $time;
	preg_match("/\[(.*?)]/", $gettime, $zona);
	$datazona = $zona[1];
	$formattime = str_replace("[" . $zona[1] . "]", "", $time);

	$args = array(
		'post_type' => 'post',
		'post_status' => 'publish',
      	'offset' => $after - 1,
		'posts_per_page'=> $jml
	);
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
		<div class="widget indeks">
			<?php if(!empty($title)): ?>
			<div class="widget-header">
				<h3 class="widget-title"><?php echo $title; ?></h3>
			</div>
			<?php endif; ?>
			<div class="widget-content">
				<?php 
				while ( $my_query->have_posts() ) {
					$my_query->the_post(); 
                    $counter = get_post_meta( get_the_ID(), 'counter', true ); ?>
						<div class="indeks-item media">
							<div class="indeks-image media-image">
								<?php if($counter["video"] != ""): ?>
									<div class="video-time"></div>
								<?php endif; ?>
		                         <?php if($counter["foto"] != ""): ?>
		                              <div class="foto-counter"></div>
		                         <?php endif; ?>
								<?php echo customthumbnail(get_the_ID(), 'thumbnail'); ?>
							</div>
							<div class="indeks-text">
								<h2>
									<a href="<?php echo get_permalink(); ?>" class="media-title"><?php echo get_the_title(); ?></a>
								</h2>
								<div class="indeks-meta">
									<?php if(!empty(labelcategory())): ?>
										<div class="indeks-category"><?php echo labelcategory(); ?></div>
									<?php endif; ?>
									<div class="indeks-date"><?php echo gettime($formattime); ?> <?php echo $datazona; ?></div>
								</div>
							</div>
						</div>
					<?php
				} wp_reset_postdata();
				?>
			</div>
			<?php if(!empty($indeks)): ?>
			<div class="widget-pagination">
				<div class="pagination-index">
					<a href="<?php echo $indeks; ?>"><?php echo $txtindeks; ?></a>
				</div>
			</div>
			<?php endif; ?>
		</div>
	<?php
	endif;
}

class indeksWidget extends WP_Widget {

	public function __construct() {
		global $app;
		$idwidget = 'indeks';
		$namewidget = $app["widget"]["indeks"]["name"];
		$descwidget = $app["widget"]["indeks"]["description"];
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				indeksViewMobile($instance['title'], $instance['after'], $instance['time'], $instance['indeks'], $instance['txtindeks'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				indeksViewMobile($instance['title'], $instance['after'], $instance['time'], $instance['indeks'], $instance['txtindeks'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				indeksViewDesktop($instance['title'], $instance['after'], $instance['time'], $instance['indeks'], $instance['txtindeks'], $instance['amountdesktop']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['after'] ) ) {
			$instance['after'] = sanitize_text_field( $new_instance['after'] );
		}
		if ( ! empty( $new_instance['time'] ) ) {
			$instance['time'] = sanitize_text_field( $new_instance['time'] );
		}
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		if ( ! empty( $new_instance['indeks'] ) ) {
			$instance['indeks'] = sanitize_text_field( $new_instance['indeks'] );
		}
		if ( ! empty( $new_instance['txtindeks'] ) ) {
			$instance['txtindeks'] = sanitize_text_field( $new_instance['txtindeks'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}

	public function form( $instance ) {
		global $app;
		$defaults = array(
			'title' => '',
			'category' => '',
			'after' => '1',
			'time' => 'j F Y H:i',
			'amountdesktop' => '3',
			'amountmobile' => '3',
			'indeks' => '',
			'txtindeks' => 'Index Berita',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo $app["widget"]["indeks"]["label"]["title"] ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'time' ); ?>"><?php echo $app["widget"]["indeks"]["label"]["time"] ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'time' ); ?>" name="<?php echo $this->get_field_name( 'time' ); ?>" value="<?php echo $instance['time']; ?>" />
				<?php echo $app["widget"]["indeks"]["label"]["desctime"] ?>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'after' ); ?>"><?php echo $app["widget"]["indeks"]["label"]["after"] ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'after' ); ?>" name="<?php echo $this->get_field_name( 'after' ); ?>" value="<?php echo $instance['after']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>"><?php echo $app["widget"]["indeks"]["label"]["amountdesktop"] ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>"><?php echo $app["widget"]["indeks"]["label"]["amountmobile"] ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'indeks' ); ?>"><?php echo $app["widget"]["indeks"]["label"]["indeks"] ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'indeks' ); ?>" name="<?php echo $this->get_field_name( 'indeks' ); ?>" value="<?php echo $instance['indeks']; ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'txtindeks' ); ?>"><?php echo $app["widget"]["indeks"]["label"]["txtindeks"] ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'txtindeks' ); ?>" name="<?php echo $this->get_field_name( 'txtindeks' ); ?>" value="<?php echo $instance['txtindeks']; ?>"/>
			</p>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>"><?php echo $app["widget"]["indeks"]["label"]["desktop"] ?></label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>"><?php echo $app["widget"]["indeks"]["label"]["mobile"] ?></label>
			</p>
		</div>
		<?php
	}
}

function indeksload() {
	register_widget( 'indeksWidget' );
}
add_action( 'widgets_init', 'indeksload' );
?>