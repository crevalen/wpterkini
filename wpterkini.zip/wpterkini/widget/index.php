<?php 
require 'headline.php';
require 'list.php';
require 'kolom.php';
require 'popular.php';
require 'grid.php';
require 'video.php';
require 'indeks.php';
require 'related.php';
require 'tag.php';
?>