<?php
function headlineViewDesktop($title, $category, $jml){
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
		'post_status' => 'publish',
		'posts_per_page'=> $jml
	);
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
		<div class="widget headline">
			<?php if(!empty($title)): ?>
			<div class="widget-header">
				<h3 class="widget-title"><?php echo $title; ?></h3>
			</div>
			<?php endif; ?>
			<div class="widget-content">
				<?php 
				$counter = 0;
				$num = 1;
				while ( $my_query->have_posts() ) {
					$my_query->the_post(); 
               		$counter = get_post_meta( get_the_ID(), 'counter', true );
					$big; 
					$small;
					$counter++; 
					$no = $num++;
					if($no == 1):
						$big .= '<div class="headline-big media">
							<div class="headline-item">
								<div class="headline-image media-image">';
	                         if($counter["video"] != ""):
	                              $big .= '<div class="video-time">' . $counter["video"]. '</div>';
	                         endif;
	                         if($counter["foto"] != ""):
	                              $big .= '<div class="foto-counter">' . $counter["foto"]. ' Foto</div>';
	                         endif;

							$big .= customthumbnail(get_the_ID(), 'image_656_369') . '
								</div>
								<div class="headline-text">
								';
						if(!empty(labelcategory())):
							$big .= '<div class="headline-category">' . labelcategory() .'</div>';
						endif;
									
						$big .= '<h2><a href="' . get_permalink() . '" class="media-title">' . get_the_title() . '</a></h2>
								</div>
							</div>
						</div>';
					endif;
					if($no > 1):
						$small .= '<div class="headline-item media">
							<div class="headline-image media-image">';
	                         if($counter["video"] != ""):
	                              $small .= '<div class="video-time">' . $counter["video"]. '</div>';
	                         endif;

	                         if($counter["foto"] != ""):
	                              $small .= '<div class="foto-counter">' . $counter["foto"]. ' Foto</div>';
	                         endif;
							$small .= customthumbnail(get_the_ID(), 'image_198_114') . '
							</div>
							<div class="headline-text">
								<h2>
									<a href="' . get_permalink() . '" class="media-title">' . get_the_title() . '</a>
								</h2>
							</div>
						</div>';
					endif;
				} wp_reset_postdata();
				if($counter == 1):
					echo $big;
				endif;
				if($counter > 1):
					echo $big . '<div class="headline-small">' . $small . '</div>';
				endif;
				?>
			</div>
		</div>
	<?php
	endif;
}
function headlineViewMobile($title, $category, $jml){
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
		'post_status' => 'publish',
		'posts_per_page'=> $jml
	);
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
		<div class="widget headline">
			<div class="widget-content">
				<?php 
				$counter = 0;
				$num = 1;
				while ( $my_query->have_posts() ) {
					$my_query->the_post(); 
               		$counter = get_post_meta( get_the_ID(), 'counter', true );
					$big; 
					$small;
					$counter++; 
					$no = $num++;
					if($no == 1):
						$big .= '<div class="headline-big media">
							<div class="headline-item">
								<div class="headline-image media-image">';
									if(!empty($title)):
									$big .= '<div class="widget-header">
										<h3 class="widget-title">' . $title . '</h3>
									</div>';
									endif; 
	                         if($counter["video"] != ""):
	                              $big .= '<div class="video-time"></div>';
	                         endif;
	                         if($counter["foto"] != ""):
	                              $big .= '<div class="foto-counter"></div>';
	                         endif;

							$big .= customthumbnail(get_the_ID(), 'image_360_203') . '
								</div>
								<div class="headline-text">
								';
									
						$big .= '<h2><a href="' . get_permalink() . '" class="media-title">' . get_the_title() . '</a></h2>';
						if(!empty(labelcategory())):
							$big .= '<div class="headline-category">' . labelcategory() .'</div>';
						endif;
								$big .= '</div>
							</div>
						</div>';
					endif;
					if($no > 1):
						$small .= '<div class="headline-item media">
							<div class="headline-image media-image">';
	                         if($counter["video"] != ""):
	                              $small .= '<div class="video-time"></div>';
	                         endif;

	                         if($counter["foto"] != ""):
	                              $small .= '<div class="foto-counter"></div>';
	                         endif;
							$small .= customthumbnail(get_the_ID(), 'thumbnail') . '
							</div>
							<div class="headline-text">
								<h2>
									<a href="' . get_permalink() . '" class="media-title">' . get_the_title() . '</a>
								</h2>
							</div>
						</div>';
					endif;
				} wp_reset_postdata();
				if($counter == 1):
					echo $big;
				endif;
				if($counter > 1):
					echo $big . '<div class="headline-small"><div class="small-box">' . $small . '</div></div>';
				endif;
				?>
			</div>
		</div>
	<?php
	endif;
}

class headline extends WP_Widget {

	public function __construct() {
		global $app;
		$idwidget = 'headline';
		$namewidget = $app["widget"]["headline"]["name"];
		$descwidget = $app["widget"]["headline"]["description"];
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				headlineViewMobile($instance['title'], $instance['category'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				headlineViewMobile($instance['title'], $instance['category'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				headlineViewDesktop($instance['title'], $instance['category'], $instance['amountdesktop']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		$instance['category'] = $new_instance['category'];
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}

	public function form( $instance ) {
		global $app;
		$defaults = array(
			'title' => '',
			'category' => '',
			'amountdesktop' => '4',
			'amountmobile' => '4',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo $app["widget"]["headline"]["label"]["title"] ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<p class="datacat">
				<label for="<?php echo $this->get_field_id( 'category' ); ?>"><?php echo $app["widget"]["headline"]["label"]["category"] ?></label>
				<div class="over">
					<?php foreach(get_terms('category','parent=0&hide_empty=0') as $term) { 
						if(!empty($instance['category'])):
							$ch = in_array( $term->term_id, $instance['category']) ? 'checked="checked"' : '';
						else:
							$ch = "";
						endif;
					?>
					<div class="over-flex">
						<input type="checkbox" id="<?php echo $this->get_field_id( 'category' ); ?>_<?php echo $term->term_id; ?>" name="<?php echo $this->get_field_name( 'category' ); ?>[]" value="<?php echo $term->term_id; ?>" <?php echo $ch; ?>>
						<label for="<?php echo $this->get_field_id( 'category' ); ?>_<?php echo $term->term_id; ?>"><?php echo $term->name; ?></label>
					</div>
					<?php } ?>
				</div>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>"><?php echo $app["widget"]["headline"]["label"]["amountdesktop"] ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>"><?php echo $app["widget"]["headline"]["label"]["amountmobile"] ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>"><?php echo $app["widget"]["headline"]["label"]["desktop"] ?></label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>"><?php echo $app["widget"]["headline"]["label"]["mobile"] ?></label>
			</p>
		<?php
	}
}

function headlineload() {
	register_widget( 'headline' );
}
add_action( 'widgets_init', 'headlineload' );
?>