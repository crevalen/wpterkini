<?php
function listViewDesktop($title, $category, $time, $jml){
	$gettime = $time;
	preg_match("/\[(.*?)]/", $gettime, $zona);
	$datazona = $zona[1];
	$formattime = str_replace("[" . $zona[1] . "]", "", $time);

	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
		'post_status' => 'publish',
		'posts_per_page'=> $jml
	);
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
		<div class="widget list">
			<?php if(!empty($title)): ?>
			<div class="widget-header">
				<h3 class="widget-title"><?php echo $title; ?></h3>
			</div>
			<?php endif; ?>
			<div class="widget-content">
				<?php 
				while ( $my_query->have_posts() ) {
					$my_query->the_post(); ?>
					<div class="list-item media">
						<div class="list-image media-image">
							<?php echo customthumbnail(get_the_ID(), 'thumbnail'); ?>
						</div>
						<div class="list-text">
							<div class="list-date"><?php echo gettime($formattime); ?> <?php echo $datazona; ?></div>
							<h2>
								<a href="<?php echo get_permalink(); ?>" class="media-title"><?php echo get_the_title(); ?></a>
							</h2>
						</div>
					</div>
					<?php
				} wp_reset_postdata();
				?>
			</div>
		</div>
	<?php
	endif;
}
function listViewMobile($title, $category, $time, $jml){
	$gettime = $time;
	preg_match("/\[(.*?)]/", $gettime, $zona);
	$datazona = $zona[1];
	$formattime = str_replace("[" . $zona[1] . "]", "", $time);

	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
		'post_status' => 'publish',
		'posts_per_page'=> $jml
	);
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
		<div class="widget list">
			<?php if(!empty($title)): ?>
			<div class="widget-header">
				<h3 class="widget-title"><?php echo $title; ?></h3>
			</div>
			<?php endif; ?>
			<div class="widget-content">
				<?php 
				while ( $my_query->have_posts() ) {
					$my_query->the_post(); ?>
					<div class="list-item media">
						<div class="list-image media-image">
							<?php echo customthumbnail(get_the_ID(), 'thumbnail'); ?>
						</div>
						<div class="list-text">
							<h2>
								<a href="<?php echo get_permalink(); ?>" class="media-title"><?php echo get_the_title(); ?></a>
							</h2>
							<div class="list-date"><?php echo gettime($formattime); ?> <?php echo $datazona; ?></div>
						</div>
					</div>
					<?php
				} wp_reset_postdata();
				?>
			</div>
		</div>
	<?php
	endif;
}

class listWidget extends WP_Widget {

	public function __construct() {
		global $app;
		$idwidget = 'list';
		$namewidget = $app["widget"]["list"]["name"];
		$descwidget = $app["widget"]["list"]["description"];
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				listViewMobile($instance['title'], $instance['category'], $instance['time'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				listViewMobile($instance['title'], $instance['category'], $instance['time'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				listViewDesktop($instance['title'], $instance['category'], $instance['time'], $instance['amountdesktop']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		$instance['category'] = $new_instance['category'];
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		if ( ! empty( $new_instance['time'] ) ) {
			$instance['time'] = sanitize_text_field( $new_instance['time'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}

	public function form( $instance ) {
		global $app;
		$defaults = array(
			'title' => '',
			'category' => '',
			'time' => 'j F Y H:i [WIB]',
			'amountdesktop' => '3',
			'amountmobile' => '3',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo $app["widget"]["list"]["label"]["title"] ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<p class="datacat">
				<label for="<?php echo $this->get_field_id( 'category' ); ?>"><?php echo $app["widget"]["list"]["label"]["category"] ?></label>
				<div class="over">
					<?php foreach(get_terms('category','parent=0&hide_empty=0') as $term) { 
						if(!empty($instance['category'])):
							$ch = in_array( $term->term_id, $instance['category']) ? 'checked="checked"' : '';
						else:
							$ch = "";
						endif;
					?>
					<div class="over-flex">
						<input type="checkbox" id="<?php echo $this->get_field_id( 'category' ); ?>_<?php echo $term->term_id; ?>" name="<?php echo $this->get_field_name( 'category' ); ?>[]" value="<?php echo $term->term_id; ?>" <?php echo $ch; ?>>
						<label for="<?php echo $this->get_field_id( 'category' ); ?>_<?php echo $term->term_id; ?>"><?php echo $term->name; ?></label>
					</div>
					<?php } ?>
				</div>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'time' ); ?>"><?php echo $app["widget"]["list"]["label"]["time"] ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'time' ); ?>" name="<?php echo $this->get_field_name( 'time' ); ?>" value="<?php echo $instance['time']; ?>" />
				<?php echo $app["widget"]["list"]["label"]["desctime"] ?>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>"><?php echo $app["widget"]["list"]["label"]["amountdesktop"] ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>"><?php echo $app["widget"]["list"]["label"]["amountmobile"] ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>"><?php echo $app["widget"]["list"]["label"]["desktop"] ?></label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>"><?php echo $app["widget"]["list"]["label"]["mobile"] ?></label>
			</p>
		</div>
		<?php
	}
}

function listload() {
	register_widget( 'listWidget' );
}
add_action( 'widgets_init', 'listload' );
?>