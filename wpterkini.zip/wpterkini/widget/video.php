<?php
function videoViewDesktop($title, $category, $jml){
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
		'post_status' => 'publish',
		'posts_per_page'=> $jml
	);
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
		<div class="widget video">
			<?php if(!empty($title)): ?>
			<div class="widget-header">
				<h3 class="widget-title"><?php echo $title; ?></h3>
			</div>
			<?php endif; ?>
			<div class="widget-content">
				<?php 
				$num = 1;
				while ( $my_query->have_posts() ) {
					$my_query->the_post(); 
                    $counter = get_post_meta( get_the_ID(), 'counter', true ); 
					$no = $num++;
					if($no == 1): ?>
						<div class="video-item media">
							<div class="video-image media-image">
								<?php if($counter["video"] != ""): ?>
								<div class="video-time"><?php echo $counter["video"]; ?></div>
								<?php endif; ?>
		                         <?php if($counter["foto"] != ""): ?>
		                              <div class="foto-counter"><?php echo $counter["foto"]; ?> Foto</div>
		                         <?php endif; ?>
								<?php echo customthumbnail(get_the_ID(), 'image_360_203'); ?>
							</div>
							<div class="video-text">
								<h2>
									<a href="<?php echo get_permalink(); ?>" class="media-title"><?php echo get_the_title(); ?></a>
								</h2>
								<div class="video-snip"><?php echo get_excerpt(150); ?></div>
							</div>
						</div>
					<?php else: ?>
						<div class="video-item media">
							<div class="video-image media-image">
								<?php if($counter["video"] != ""): ?>
								<div class="video-time"><?php echo $counter["video"]; ?></div>
								<?php endif; ?>
								<?php echo customthumbnail(get_the_ID(), 'image_198_114'); ?>
							</div>
							<div class="video-text">
								<h2>
									<a href="<?php echo get_permalink(); ?>" class="media-title"><?php echo get_the_title(); ?></a>
								</h2>
							</div>
						</div>
					<?php endif;
				} wp_reset_postdata();
				?>
			</div>
		</div>
	<?php
	endif;
}
function videoViewMobile($title, $category, $jml){
	$args = array(
		'category__in' => $category,
		'post_type' => 'post',
		'post_status' => 'publish',
		'posts_per_page'=> $jml
	);
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>
		<div class="widget video">
			<?php if(!empty($title)): ?>
			<div class="widget-header">
				<h3 class="widget-title"><?php echo $title; ?></h3>
			</div>
			<?php endif; ?>
			<div class="widget-content">
				<?php 
				$num = 1;
				while ( $my_query->have_posts() ) {
					$my_query->the_post(); 
                    $counter = get_post_meta( get_the_ID(), 'counter', true ); 
					$no = $num++;
					if($no == 1): ?>
						<div class="video-item media">
							<div class="video-image media-image">
								<?php if($counter["video"] != ""): ?>
								<div class="video-time"><?php echo $counter["video"]; ?></div>
								<?php endif; ?>
		                         <?php if($counter["foto"] != ""): ?>
		                              <div class="foto-counter"><?php echo $counter["foto"]; ?> Foto</div>
		                         <?php endif; ?>
								<?php echo customthumbnail(get_the_ID(), 'image_198_114'); ?>
							</div>
							<div class="video-text">
								<h2>
									<a href="<?php echo get_permalink(); ?>" class="media-title"><?php echo get_the_title(); ?></a>
								</h2>
								<div class="video-snip"><?php echo get_excerpt(150); ?></div>
							</div>
						</div>
					<?php else: ?>
						<div class="video-item media">
							<div class="video-image media-image">
								<?php if($counter["video"] != ""): ?>
								<div class="video-time"><?php echo $counter["video"]; ?></div>
								<?php endif; ?>
								<?php echo customthumbnail(get_the_ID(), 'image_198_114'); ?>
							</div>
							<div class="video-text">
								<h2>
									<a href="<?php echo get_permalink(); ?>" class="media-title"><?php echo get_the_title(); ?></a>
								</h2>
							</div>
						</div>
					<?php endif;
				} wp_reset_postdata();
				?>
			</div>
		</div>
	<?php
	endif;
}

class videoWidget extends WP_Widget {

	public function __construct() {
		global $app;
		$idwidget = 'video';
		$namewidget = $app["widget"]["video"]["name"];
		$descwidget = $app["widget"]["video"]["description"];
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				videoViewMobile($instance['title'], $instance['category'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				videoViewMobile($instance['title'], $instance['category'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				videoViewDesktop($instance['title'], $instance['category'], $instance['amountdesktop']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		$instance['category'] = $new_instance['category'];
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}

	public function form( $instance ) {
		global $app;
		$defaults = array(
			'title' => '',
			'category' => '',
			'amountdesktop' => '5',
			'amountmobile' => '5',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo $app["widget"]["video"]["label"]["title"] ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<p class="datacat">
				<label for="<?php echo $this->get_field_id( 'category' ); ?>"><?php echo $app["widget"]["video"]["label"]["category"] ?></label>
				<div class="over">
					<?php foreach(get_terms('category','parent=0&hide_empty=0') as $term) { 
						if(!empty($instance['category'])):
							$ch = in_array( $term->term_id, $instance['category']) ? 'checked="checked"' : '';
						else:
							$ch = "";
						endif;
					?>
					<div class="over-flex">
						<input type="checkbox" id="<?php echo $this->get_field_id( 'category' ); ?>_<?php echo $term->term_id; ?>" name="<?php echo $this->get_field_name( 'category' ); ?>[]" value="<?php echo $term->term_id; ?>" <?php echo $ch; ?>>
						<label for="<?php echo $this->get_field_id( 'category' ); ?>_<?php echo $term->term_id; ?>"><?php echo $term->name; ?></label>
					</div>
					<?php } ?>
				</div>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>"><?php echo $app["widget"]["video"]["label"]["amountdesktop"] ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>"><?php echo $app["widget"]["video"]["label"]["amountmobile"] ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>"><?php echo $app["widget"]["video"]["label"]["desktop"] ?></label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>"><?php echo $app["widget"]["video"]["label"]["mobile"] ?></label>
			</p>
		</div>
		<?php
	}
}

function videoload() {
	register_widget( 'videoWidget' );
}
add_action( 'widgets_init', 'videoload' );
?>