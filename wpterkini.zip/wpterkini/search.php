<?php get_template_part("header"); ?>
<?php get_template_part("template-parts/header/index"); ?>
<?php get_template_part("template-parts/search/index"); ?>
<?php get_template_part("footer"); ?>